# Annotated bibliography (Month 1)

Verified: checked against a publisher, author CV, Glottolog, PubMed Central, or the dataset's own bibliography during this session. Unverified entries are marked.

## Timucua: texts, grammar, lexicon
- **Broadwell, G. A. 2024.** *The Timucua Language: A Text-Based Reference Grammar.* Lincoln: University of Nebraska Press.
  - The gold standard for Workstream A (affix boundaries, phonology).
- **Broadwell, G. A. 2016 to 2025.** *A Timucua–English Dictionary.* Webonary: timucua.webonary.org.
  - The most important missing dataset. A full lexicon built from the 17th-century texts would replace the 100-item ASJP list in Workstream B. Ask for a LIFT or FLEx export.
- **Dubcovsky, A., G. A. Broadwell, et al. 2020 to 2024.** *Hebuano: A Timucua Language Resource Guide.* hebuano.com.
  - Teaching and reference hub with bibliography.
- **Dubcovsky, A. & G. A. Broadwell. 2017.** Writing Timucua: Recovering and interrogating Indigenous authorship. *Early American Studies* 15(3): 409–441. doi:10.1353/eam.2017.0016.
  - Corpus size and authorship arguments for the dialect/authorship work.
- **Broadwell, G. A. 2018.** Shadow authors: The texts of the earliest Indigenous Florida writers. In J. M. Burns & T. J. Johnson (eds.), *Franciscans and American Indians in Pan-Borderlands Perspective*, 161–174. Academy of American Franciscan History.
  - The proposal cites this as an undated manuscript; it has since been published.
- **Broadwell, G. A. & A. Dubcovsky. 2023.** Chief Manuel's 1651 Timucua letter: The oldest letter in a Native language of the United States. *Proceedings of the American Philosophical Society* 164(3/4): 225–267.
  - Native-authored, non-translated register; baseline for authorship.
- **Dubcovsky, A. & G. A. Broadwell. 2024.** The "Jesus María Letter," a seventeenth-century Timucua epistle. In R. L. Barnes & G. Goodman (eds.), *American Contact*, 100–108. University of Pennsylvania Press.
  - The 1688 letter.
- **Broadwell, G. A. 2014.** Timucua -ta: Muskogean parallels. In M. D. Picone & C. E. Davies (eds.), *New Perspectives on Language Variety in the South*, 72–81. Tuscaloosa: University of Alabama Press.
  - Missing from the proposal and directly relevant to H3, since it treats grammatical parallels between Timucua and Muskogean.
- **Granberry, J. 1993.** *A Grammar and Dictionary of the Timucua Language*, 3rd ed. Tuscaloosa: University of Alabama Press.
  - Source of the ASJP Timucua list used in this pilot, and of the Warao and loanword proposals.
- **Broadwell, G. A. 1995.** Review of Granberry (1993). *Southeastern Archaeology* 14(1): 101.
  - Read alongside Granberry.
- **Campbell, L. 1997.** *American Indian Languages: The Historical Linguistics of Native America.* Oxford: Oxford University Press.
  - Evaluates the Warao proposal.

## Timucua ethnohistory and geography
- **Hann, J. H. 1996.** *A History of the Timucua Indians and Missions.* Gainesville: University Press of Florida.
  - Town names and etymologies (Eloquale, La Chua); used for the gazetteer.
- **Worth, J. E. 1998.** *The Timucuan Chiefdoms of Spanish Florida*, 2 vols. Gainesville: University Press of Florida.
  - Province geography (Arapaha, Yustaga) and the 18th-century collapse.
- **Milanich, J. T. 1996.** *The Timucua.* Oxford: Blackwell.
  - Overview; cited for the Suwannee as San Juan.

## Muskogean
- **Martin, J. B. 2011.** *A Grammar of Creek (Muskogee).* Lincoln: University of Nebraska Press.
  - Basis for normalization rule R4 (infinitive -itá).
- **Martin, J. B. & M. McKane Mauldin. 2000.** *A Dictionary of Creek/Muskogee.* Lincoln: University of Nebraska Press.
  - Needed to check the Creek residue items by hand.
- **Booker, K. M. 2005.** Muskogean historical phonology. In H. K. Hardy & J. Scancarelli (eds.), *Native Languages of the Southeastern United States*, 246–298. Lincoln: University of Nebraska Press.
  - Source of the Proto-Muskogean forms used for the Stage 2 cross-check.
- **Kimball, G. 1988.** An Apalachee vocabulary. *International Journal of American Linguistics* 54(4): 387–398. JSTOR 1265100.
  - Source of the H4 Apalachee list (Addendum 1). Finds one Apalachee–Timucua shared word, holahta 'chief' (Apalachee into Timucua).
- **Kimball, G. 1987.** A grammatical sketch of Apalachee. *International Journal of American Linguistics* 53(2): 136–174. JSTOR 1265142.
- **Haas, M. R. 1949.** The position of Apalachee in the Muskogean family. *International Journal of American Linguistics* 15(2): 121–127. JSTOR 1262772.
- **Gatschet, A. S. 1884.** *A Migration Legend of the Creek Indians*, vol. 1. Philadelphia: D. G. Brinton. archive.org: migrationcreek00gatsrich.
  - Source of the H1 Hitchiti list (Addendum 2): pp. 56, 71, 80 to 83. The Hitchiti came from Judge G. W. Stidham of Eufaula, who as a child saw his tribe move from the Chattahoochee (preface), so it is a pre-Florida baseline.
  - Also used for the gazetteer (Wacissa/Basisa p. 72; Asile p. 75; Okoni pp. 68, 78, 141) and for H3 (p. 58: ifa 'dog' "went over from them to the Timucua").
- **Haas, M. R. 1937.** Hitchiti field notebook I (consultant Willie Haney, Eufaula, Oklahoma). Mary R. Haas Papers, Mss.Ms.Coll.94, box 19, American Philosophical Society. Scan Haas.038, supplied by Dennis. ✓
  - About 21 pages: numerals, colors, kinship, a few verbs. Agrees with Gatschet on all 17 shared concepts, but adds none of the 17 unchecked Mikasuki residue words. Haney's grandfather came from Florida (p. 14), so it is a weaker pre-Florida baseline than Gatschet.
- **American Philosophical Society. 2026.** Finding aid, Mary R. Haas Papers, Mss.Ms.Coll.94 (ArchivesSpace export, supplied by Dennis). ✓
  - Gives the boxes in the data access plan below.
- **Haas, M. R. 1938 to 1940.** Brief Hitchiti vocabulary and grammatical notes. National Anthropological Archives MS, Smithsonian Institution. *Cited in Boynton (1982); not seen.*
- **Swanton, J. R. 1921 to 1922.** A sketch of the Hitchiti language. National Anthropological Archives MS 4148, Smithsonian Institution. *Cited in Boynton (1982); not seen.*
- **Boynton, S. S. 1982.** *Mikasuki Grammar in Outline.* PhD dissertation, University of Florida. archive.org: mikasukigrammari00boyn. ✓
  - Attests 5 of the 8 strict Mikasuki residue forms (flesh akni, head yos-, belly lamp-, burn yil-, and blue honotb- inside the ASJP 'green'), so the residue is not an ASJP transcription error. Its bibliography is the source of the two NAA Hitchiti manuscripts above.
  - The APS Phillips Fund holds only a copy of this dissertation (Mss.497.3.Am4, guide supplied by Dennis), so no separate Boynton materials need requesting.
- **Derrick-Mescua, M. T. 1980.** *A Phonology and Morphology of Mikasuki.* PhD dissertation, University of Florida. *Cited in Boynton (1982); not seen.*
- **West, J. D. 1962.** The phonology of Mikasuki. *Studies in Linguistics* 16(3–4): 77–91. *Cited in Boynton (1982); not seen.* West's Mikasuki work is also the basis of Haas's Mikasuki Lexicon #1 (APS box 139).
- **Broadwell, G. A. 1991.** The Muskogean connection of the Guale and Yamasee. *IJAL* 57(2): 267–270.
  - Coastal Georgia neighbors of the Mocama; relevant to where contact could have happened.
- **Broadwell, G. A. 2019.** Muskogean languages. In D. Siddiqi et al. (eds.), *Routledge Handbook of North American Languages*, 397–423.
  - Current overview of the family.
- **Sturtevant, W. C. 1971.** Creek into Seminole. In E. B. Leacock & N. O. Lurie (eds.), *North American Indians in Historical Perspective.* New York: Random House. *Unverified: pages.*
  - Classic account of Seminole ethnogenesis.

## Methods
- **List, J.-M. 2012.** LexStat: Automatic detection of cognates in multilingual wordlists. *Proceedings of LINGVIS & UNCLH*, 117–125.
- **List, J.-M., S. J. Greenhill & R. D. Gray. 2017.** The potential of automatic word comparison for historical linguistics. *PLoS ONE* 12(1): e0170046.
  - Basis for the 0.55 LexStat threshold.
- **List, J.-M. & R. Forkel. 2022.** Automated identification of borrowings in multilingual wordlists [version 3]. *Open Research Europe* 1: 79. doi:10.12688/openreseurope.13843.3.
  - The two-stage workflow. Note that the paper links cross-family sets at an average SCA distance below 0.3, which is stricter than the cut used here.
- **Hantgan, A., H. Babiker & J.-M. List. 2022.** First steps towards the detection of contact layers in Bangime: A multi-disciplinary, computer-assisted approach. *Open Research Europe* 2: 10.
- **Miller, J. E., T. Tresoldi, R. Zariquiey, C. A. Beltrán Castañón, N. Morozova & J.-M. List. 2020.** Using lexical language models to detect borrowings in monolingual wordlists. *PLoS ONE* 15(12): e0242709.
  - Basis for criterion C4 (phonotactic fit).
- **Kessler, B. 2001.** *The Significance of Word Lists.* Stanford: CSLI.
  - Permutation test.
- **Ringe, D. 1992.** On calculating the factor of chance in language comparison. *Transactions of the American Philosophical Society* 82(1).
- **Turchin, P., I. Peiros & M. Gell-Mann. 2010.** Analyzing genetic connections between languages by matching consonant classes. *Journal of Language Relationship* 3.
  - The TPG measure.
- **Benjamini, Y. & Y. Hochberg. 1995.** Controlling the false discovery rate. *Journal of the Royal Statistical Society B* 57(1): 289–300.
- **Forkel, R., J.-M. List, S. J. Greenhill, et al. 2018.** Cross-Linguistic Data Formats. *Scientific Data* 5: 180205.
- **Wichmann, S., E. W. Holman & C. H. Brown (eds.). 2022.** *The ASJP Database*, version 20.
  - Pilot data. CLDF version: lexibank/asjp, commit cf4bf0d.
- **Haspelmath, M. & U. Tadmor (eds.). 2009.** *World Loanword Database* (WOLD).
  - Gold-standard loans for validation, and per-meaning borrowability scores.
- **Key, M. R. & B. Comrie (eds.).** *The Intercontinental Dictionary Series* (IDS).
  - Spanish donor list for validation.
- **Dryer, M. S. & M. Haspelmath (eds.). 2013.** *WALS Online.*
- **Creutz & Lagus 2007; Dyer, Chahuneau & Smith 2013; Brown et al. 1993; Luo, Cao & Barzilay 2019; Luo et al. 2021.** As cited in the proposal; not re-verified.

## Place names
- **Read, W. A. 1934.** *Florida Place-Names of Indian Origin and Seminole Personal Names.* Baton Rouge: LSU Press.
  - Public domain on archive.org; reprinted by the University of Alabama Press.
- **Simpson, J. C. 1956.** *Florida Place-Names of Indian Derivation*, ed. M. F. Boyd. Tallahassee: Florida Geological Survey.
- **Bright, W. 2004.** *Native American Placenames of the United States.* Norman: University of Oklahoma Press.
- **Krakow, K. K. 1975.** *Georgia Place-Names.* Macon: Winship Press.

## Corrections to the proposal's reference list
1. **Apalachee sources:** the proposal cites none. Add Kimball (1987; 1988) and Haas (1949), which H4 depends on.
2. **Broadwell n.d. "Shadow authors":** published in 2018 (see above).
3. **Dubcovsky & Broadwell (2017):** add volume 15(3), pages 409–441 and the DOI.
4. **List & Forkel (2022):** cite as Open Research Europe 1: 79, version 3, with the DOI.
5. **Add** Broadwell (2014), Booker (2005), Gatschet (1884) and the Webonary dictionary.
6. **Haas Hitchiti field notebook:** the proposal places it at the California Language Archive. It is in the Haas Papers at the APS (Mss.Ms.Coll.94, box 19).
7. **Boynton (1982) "Mikasuki materials":** the Phillips Fund item is a copy of her dissertation, *Mikasuki Grammar in Outline*, also on archive.org. Cite the dissertation.

# Data access plan

Box numbers are from the APS finding aid for the Mary R. Haas Papers (Mss.Ms.Coll.94).

| Need | Holder | Unblocks | Ask |
|---|---|---|---|
| Timucua lexicon (full) | Broadwell, Webonary dictionary | Workstream B at 350 concepts | LIFT/FLEx export, or permission to compile a 350-concept list from the public site |
| Timucua corpus with parallel Spanish | Broadwell (UF) | Workstream A | Read-only research copy plus a data-use agreement |
| Hitchiti, the other 17 Mikasuki residue words | APS: Hitchiti Lexicon, box 130 (200 to 400 cards, English order, full range). NAA: Swanton MS 4148 (1921 to 1922); Haas Hitchiti vocabulary (1938 to 1940) | H1 beyond 3 words | Request scans of box 130 from APS; ask NAA for the two manuscripts |
| Hitchiti (in hand) | Gatschet 1884; Haas 1937 notebook (box 19) | H1 for 3 words | Done (Addendum 2 and the 1937 check) |
| Mikasuki (fuller) | APS: Mikasuki Lexicon #1 (West), box 139, and #2 (Sturtevant), box 140, both digitized; Comparative Color Terms, box 10, digitized (Hitchiti and Mikasuki, covers 'green') | Larger Mikasuki list; checks of the residue | Download from the APS Digital Library (nodes 393462, 393463, 390943) |
| Mikasuki (in hand) | Boynton 1982 | Residue form check | Done: 5 of 8 strict residue forms attested |
| Muskogean comparisons | APS: Proto-Muskogean Lexicon, box 169 (700 to 1,400 cards); Seminole Lexicon by Sturtevant, box 18 | Stage 2 hand check | Request scans of box 169 |
| Timucua comparisons | APS: Timucua Lexicon, box 158; Tawasa–Timucua Comparative Lexicon, box 25; Granberry correspondence (1982, Hitchiti and Timucua), box 2 | Stage 7 review; what Haas already compared | Request scans |
| Apalachee | Kimball 1988, Kimball 1987, Haas 1949 (in hand) | H4 calibration | Done (Addendum 1) |
| Mikasuki recordings | Sturtevant & Jumper 1951 (California Language Archive) | Larger Mikasuki list | Ask CLA about access |
| Creek | Martin & Mauldin 2000 | Manual Stage 2 check | FSU Libraries |
| Specialist reviewers | Broadwell (Timucua, Muskogean); Jack B. Martin, William & Mary (Creek, Muskogean; earlier Timucua concordance work with Ann Reed) | Stage 7 review, C5 and C6 | See emails below |
| Community guidance | Seminole Tribe of Florida and Miccosukee Tribe of Indians of Florida, through their culture and education offices | Ethics (proposal section 9) | Go through a faculty mentor; confirm the right office on each tribe's official site first |
