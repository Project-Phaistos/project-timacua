"""Descriptive checks on two sources supplied after Addendum 2. No Timucua comparison is computed.

1. Haas (1937) Hitchiti field notebook I (APS Mss.Ms.Coll.94, box 19; scan Haas.038), consultant
   Willie Haney, Eufaula, Oklahoma. Transcribed in cldf_addendum/hitchiti_haas1937_forms.csv.
   a. Which of the 20 Mikasuki residue concepts does it cover? (Extends Addendum 2, part A.)
   b. Does it agree with Gatschet (1884) where both cover a concept? (SCA >= 0.55, frozen cut.)
2. Boynton (1982), Mikasuki Grammar in Outline: which ASJP Mikasuki residue forms does the grammar
   attest? (Hand check in cldf_addendum/mikasuki_boynton1982_checks.csv; summarized here.)
3. Corrects the H1 count in results/h1_hitchiti/h1_summary.json. The frozen script applied ~ to an
   object column and reported absent_from_hitchiti = -6; the correct count is computed here. The
   verdict is unaffected.
"""
import json
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
from common import ROOT, sim_sca  # noqa: E402

OUT = os.path.join(ROOT, "results", "h1_hitchiti")


def main():
    haas = pd.read_csv(os.path.join(ROOT, "cldf_addendum", "hitchiti_haas1937_forms.csv"))
    gat = pd.read_csv(os.path.join(ROOT, "cldf_addendum", "hitchiti_forms.csv"))
    haas["Parameter_ID"] = haas.Parameter_ID.astype(str); gat["Parameter_ID"] = gat.Parameter_ID.astype(str)
    resid = json.load(open(os.path.join(ROOT, "results", "residue_concepts.json")))
    gloss = dict(zip(pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv")).ID.astype(str),
                     pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv")).Name))

    # 1a. residue coverage
    cov_haas = [gloss[c] for c in resid["MIKASUKI"] if c in set(haas.Parameter_ID)]
    cov_gat = [gloss[c] for c in resid["MIKASUKI"] if c in set(gat.Parameter_ID)]
    new = sorted(set(cov_haas) - set(cov_gat))

    # 1b. Haas vs Gatschet agreement
    rows = []
    for c in sorted(set(haas.Parameter_ID) & set(gat.Parameter_ID), key=int):
        hf = list(haas[haas.Parameter_ID == c].Segments); gf = list(gat[gat.Parameter_ID == c].Segments)
        s, a, b = max((sim_sca(x, y), x, y) for x in hf for y in gf)
        rows.append(dict(concept=gloss[c], haas=a.replace(" ", ""), gatschet=b.replace(" ", ""), sca=round(s, 3),
                         agree=s >= 0.55, loose=bool(haas[haas.Parameter_ID == c].Note.fillna("").str.contains("loose").any())))
    agr = pd.DataFrame(rows)
    agr.to_csv(os.path.join(OUT, "haas1937_vs_gatschet1884.csv"), index=False)

    # 2. Boynton
    boy = pd.read_csv(os.path.join(ROOT, "cldf_addendum", "mikasuki_boynton1982_checks.csv"))
    strict = boy[boy.In_strict_residue == "yes"]

    # 3. H1 count correction
    h1 = pd.read_csv(os.path.join(OUT, "h1_mikasuki_residue_vs_hitchiti.csv"))
    cov = h1[h1.hitchiti_covered.astype(bool)]
    absent = int((cov.attested_in_hitchiti.astype(str) != "True").sum())

    out = dict(
        haas1937=dict(mikasuki_residue_covered=cov_haas, newly_covered_vs_gatschet=new,
                      shared_concepts_with_gatschet=int(len(agr)), agree=int(agr.agree.sum()),
                      disagree=agr[~agr.agree].concept.tolist()),
        boynton1982=dict(residue_confirmed=boy[boy.Status == "confirmed"].Concept.tolist(),
                         residue_partly_confirmed=boy[boy.Status == "partly confirmed"].Concept.tolist(),
                         strict_residue_confirmed=f"{int((strict.Status != 'not found').sum())} of {len(strict)}"),
        h1_count_correction=dict(checkable=int(len(cov)), absent_from_hitchiti=absent,
                                 note="h1_summary.json reports -6 because the frozen script applied ~ to an object "
                                      "column; the verdict (not supported) is unchanged"),
    )
    json.dump(out, open(os.path.join(OUT, "haas1937_boynton_summary.json"), "w"), indent=2)
    print(agr.to_string()); print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
