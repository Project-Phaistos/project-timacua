"""Freeze the pre-registration: SHA-256 of the protocol, frozen inputs and analysis code,
plus one combined fingerprint that can be posted publicly (OSF, a public commit) as an
external timestamp."""
import datetime
import glob
import hashlib
import os

from common import ROOT

FILES = (["prereg/PREREGISTRATION.md", "results/residue_concepts.json", "results/stage2_muskogean_cognates.csv",
          "results/stage3_residue_pool.csv", "cldf/forms.csv", "cldf/languages.csv", "cldf/control_panel.csv",
          "cldf/concept_strata.csv", "cldf/normalization_log.csv", "validation/placebo_and_calibration.csv",
          "validation/placebo_and_calibration_stratified.csv", "validation/wold_aggregate.csv",
          "validation/power_grid.csv"]
         + sorted(os.path.relpath(p, ROOT) for p in glob.glob(os.path.join(ROOT, "src", "*.py"))))


def sha(p):
    h = hashlib.sha256()
    with open(os.path.join(ROOT, p), "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def main():
    grid = glob.glob(os.path.join(ROOT, "results", "grid", "*TIMUCUA*"))
    assert not grid, "Timucua similarities already exist; freezing would be invalid"
    lines = [f"{sha(p)}  {p}" for p in FILES]
    combined = hashlib.sha256("\n".join(lines).encode()).hexdigest()
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    out = [f"Frozen (UTC): {ts}", "Timucua similarity files present at freezing: 0",
           f"Combined fingerprint: {combined}", ""] + lines
    with open(os.path.join(ROOT, "prereg", "PREREG_HASHES.txt"), "w") as f:
        f.write("\n".join(out) + "\n")
    print("\n".join(out[:3]))


if __name__ == "__main__":
    main()
