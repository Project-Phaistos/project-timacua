"""Stages 4-8 of Workstream B, exactly as frozen in prereg/PREREGISTRATION.md.
Requires the post-freeze similarity grid (05_similarity_grid.py post).

Outputs (results/):
  h2_tests.csv               every H2 test (confirmatory + secondary) with rule fields and verdict
  twoway_<label>.csv         full two-way grid for each test
  candidates_mikasuki.csv / candidates_creek.csv   Stage 4 candidates with C1-C7 and tiers
  h3_direction.csv, h3_timucua_items.csv
  exploratory.csv            Warao x Timucua and full-list descriptive tests
  summary.json
"""
import json
import math
import os
from collections import Counter

import numpy as np
import pandas as pd
from scipy.stats import binomtest
from lingpy.sequence.sound_classes import tokens2class

from common import MUSKOGEAN, ROOT, bh, concept_forms, load_cldf_forms
from twoway import get, load_strata, summarize, twoway

RES = os.path.join(ROOT, "results")
# code-path test only: DRYRUN_DONOR swaps in a non-Timucua donor and writes to RES_OUT
DONOR = os.environ.get("DRYRUN_DONOR", "TIMUCUA")
OUT = os.environ.get("RES_OUT", RES)
os.makedirs(OUT, exist_ok=True)


class BigramLM:
    def __init__(self, words):
        self.c2, self.c1, self.V = Counter(), Counter(), set()
        for w in words:
            self.add(w, +1)

    @staticmethod
    def seq(w):
        return ["#"] + list(tokens2class(w.split(), "sca")) + ["$"]

    def add(self, w, sgn):
        s = self.seq(w)
        for a, b in zip(s, s[1:]):
            self.c2[(a, b)] += sgn; self.c1[a] += sgn; self.V.add(b)

    def ll(self, w):
        s = self.seq(w); V = len(self.V) + 1
        return sum(math.log((self.c2[(a, b)] + 1) / (self.c1[a] + V)) for a, b in zip(s, s[1:])) / (len(s) - 1)


def verdict(s):
    a = s["focal_p_perm"] < 0.05
    b = s["focal_dS"] > s["primary_control_dS"]
    c = s["focal_dS"] > s["recipient_panel_q95_dS"]
    cs = s["focal_p_max"] < 0.05
    A, B = a and cs, a and b and c
    s.update(rule_a=a, rule_b=b, rule_c=c, rule_cstar=cs, ruleset_A=A, ruleset_B=B,
             verdict="supported" if A and B else "inconclusive" if (A or B) else "H0 retained")
    return s


def main():
    langs = pd.read_csv(os.path.join(ROOT, "cldf", "languages.csv"))
    macro = dict(zip(langs.ID, langs.Macroarea)); macro["MUSK_INHERITED"] = "North America"
    panel = list(pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID)
    params = pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv"))
    gloss = dict(zip(params.ID.astype(str), params.Name))
    forms = load_cldf_forms(); forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    allf = {L: concept_forms(forms, L) for L in forms.Language_ID.unique()}
    resid = json.load(open(os.path.join(RES, "residue_concepts.json")))
    T = allf[DONOR]

    tests = []

    def run(label, row, col, C, measure, role, strata=None, record=True):
        df = twoway(row, col, C, measure, panel, macro, strata=strata)
        if record:
            df.to_csv(os.path.join(OUT, f"twoway_{label}.csv"), index=False)
        s = verdict(summarize(df, row, col))
        s.update(label=label, row=row, col=col, measure=measure, role=role)
        if record:
            tests.append(s)
        print(f"{label:45s} n={s['focal_n_items']:2d} dS={s['focal_dS']:+.3f} z={s['focal_z']:+.2f} "
              f"p_perm={s['focal_p_perm']:.4f} p_row={s['focal_p_row']:.3f} p_col={s['focal_p_col']:.3f} prim={s['primary_control_dS']:+.3f} "
              f"q95={s['recipient_panel_q95_dS']:+.3f} -> {s['verdict']}", flush=True)
        return df, s

    # ---------------------------------------------------------------- H2
    for measure in ["SCA", "NED", "TPG"]:
        for sname in ["MIKASUKI", "MIKASUKI_strict", "MIKASUKI_keep_european_flagged",
                      "CREEK", "CREEK_strict", "CREEK_keep_european_flagged"]:
            L = sname.split("_")[0]
            role = "CONFIRMATORY" if (sname == "MIKASUKI" and measure == "SCA") else "secondary"
            run(f"H2_{sname}_{measure}", L, DONOR, resid[sname], measure, role)
    # pre-registered sensitivity: stratified permutation (5 semantic strata) for the confirmatory test
    run("H2_MIKASUKI_SCA_stratified", "MIKASUKI", DONOR, resid["MIKASUKI"], "SCA", "sensitivity", strata=load_strata())
    H2 = pd.DataFrame(tests)
    H2.to_csv(os.path.join(OUT, "h2_tests.csv"), index=False)
    # pre-registered robustness: leave-one-concept-out for the confirmatory test
    r0, c0, _ = get("MIKASUKI", DONOR, "SCA")
    Cf = [c for c in resid["MIKASUKI"] if c in r0 and c in c0]
    loo = []
    for c in Cf:
        _, s = run(f"LOO_minus_{gloss[c]}", "MIKASUKI", DONOR, [x for x in Cf if x != c], "SCA", "loo", record=False)
        loo.append(dict(dropped=gloss[c], dS=s["focal_dS"], z=s["focal_z"], p_perm=s["focal_p_perm"],
                        p_row=s["focal_p_row"], p_col=s["focal_p_col"], p_max=s["focal_p_max"], verdict=s["verdict"]))
    pd.DataFrame(loo).to_csv(os.path.join(OUT, "h2_leave_one_out.csv"), index=False)

    # ---------------------------------------------------------------- exploratory / descriptive
    ex_start = len(tests)
    for L in ["MIKASUKI", "CREEK"]:
        C = sorted(set(allf[L]) & set(T), key=int)
        run(f"descriptive_{L}_fulllist_SCA", L, DONOR, C, "SCA", "descriptive")
    C = sorted(set(allf["WARAO"]) & set(T), key=int)
    run("exploratory_WARAO_x_TIMUCUA_SCA", "WARAO", DONOR, C, "SCA", "exploratory")
    pd.DataFrame(tests[ex_start:]).to_csv(os.path.join(OUT, "exploratory.csv"), index=False)

    # ---------------------------------------------------------------- candidates and tiers
    mus_words = [s for L in MUSKOGEAN for v in allf[L].values() for s in v]
    lmT = BigramLM([s for v in T.values() for s in v]); lmM = BigramLM(mus_words)
    s3 = pd.read_csv(os.path.join(RES, "stage3_residue_pool.csv")); s3["Parameter_ID"] = s3.Parameter_ID.astype(str)
    from common import sim_sca
    cands = {}
    for L in ["MIKASUKI", "CREEK"]:
        rows, cols, M = get(L, DONOR, "SCA")
        R = [c for c in resid[L] if c in rows and c in cols]
        recs = []
        for c in R:
            i, j = rows.index(c), cols.index(c)
            obs = M[i, j]; others = np.delete(M[i], j)
            p = (1 + (others >= obs).sum()) / (1 + len(others))
            sim, w, t = max((sim_sca(a, b), a, b) for a in allf[L][c] for b in T[c])
            lmM.add(w, -1); llT, llM = lmT.ll(w), lmM.ll(w); lmM.add(w, +1)
            k = int(np.argmax(np.where(np.arange(len(cols)) == j, -9, M[i])))
            recs.append(dict(language=L, concept=gloss[c], parameter_id=c, recipient_form=w, timucua_form=t,
                             all_timucua_forms=" | ".join(T[c]), sim=round(obs, 3),
                             rank_among_timucua_concepts=int((others > obs).sum()) + 1, n_timucua_concepts=len(cols),
                             p_candidate=round(p, 4), best_other_concept=gloss[cols[k]],
                             best_other_form=" | ".join(T[cols[k]]), best_other_sim=round(float(others.max()), 3),
                             loglik_timucua=round(llT, 3), loglik_muskogean=round(llM, 3)))
        df = pd.DataFrame(recs)
        rej, padj = bh(df.p_candidate.values, 0.05)
        df["p_bh"] = np.round(padj, 4)
        df["C1_no_muskogean_etymology"] = True
        df["C2_survives_BH"] = rej
        df["C3_semantic_fit"] = True
        df["C4_phonotactic_fit_timucua"] = df.loglik_timucua > df.loglik_muskogean
        df["C5_opacity"] = "unassessed (expert)"
        df["C6_chronology"] = "unassessed (needs Hitchiti)"
        flagged = set(s3[(s3.Language_ID == L) & s3.european_flag].Parameter_ID)
        df["C7_not_european"] = ~df.parameter_id.isin(flagged)
        met = df[["C1_no_muskogean_etymology", "C2_survives_BH", "C3_semantic_fit", "C4_phonotactic_fit_timucua",
                  "C7_not_european"]].astype(int).sum(axis=1)
        df["criteria_met_of_5_assessable"] = met
        possible = (df.C1_no_muskogean_etymology & df.C3_semantic_fit & df.C4_phonotactic_fit_timucua
                    & df.C7_not_european & (df.p_candidate <= 0.05))
        df["tier"] = np.where((met >= 6) & df.C2_survives_BH, "strong", np.where(possible, "possible", "rejected"))
        df = df.sort_values(["p_candidate", "sim"], ascending=[True, False])
        df.to_csv(os.path.join(OUT, f"candidates_{L.lower()}.csv"), index=False)
        cands[L] = df
        print(df[["concept", "recipient_form", "timucua_form", "sim", "rank_among_timucua_concepts", "p_candidate",
                  "p_bh", "C4_phonotactic_fit_timucua", "tier"]].to_string(), flush=True)

    # ---------------------------------------------------------------- H3
    rows, cols, M = get(DONOR, "MUSK_INHERITED", "SCA")
    C3 = [c for c in rows if c in cols]
    df3, s3h = run("H3_TIMUCUA_x_MUSK_INHERITED_SCA", DONOR, "MUSK_INHERITED", C3, "SCA", "H3")
    pT = []
    for c in C3:
        i, j = rows.index(c), cols.index(c)
        pT.append((1 + (np.delete(M[i], j) >= M[i, j]).sum()) / len(cols))
    pR = list(pd.concat(cands.values()).p_candidate)
    kT, nT, kR, nR = sum(p <= 0.05 for p in pT), len(pT), sum(p <= 0.05 for p in pR), len(pR)
    h3 = pd.DataFrame([
        dict(direction="Muskogean->Timucua", n=nT, k_p_le_05=kT, rate=kT / nT,
             binom_p=binomtest(kT, nT, 0.05, alternative="greater").pvalue),
        dict(direction="Timucua->Muskogean (Mikasuki+Creek residue)", n=nR, k_p_le_05=kR, rate=kR / nR,
             binom_p=binomtest(kR, nR, 0.05, alternative="greater").pvalue)])
    h3["aggregate_rule_a"] = s3h["rule_a"]; h3["aggregate_rule_cstar"] = s3h["rule_cstar"]
    h3["H3_supported"] = bool(s3h["rule_a"] and s3h["rule_cstar"] and kT / nT > kR / nR)
    h3.to_csv(os.path.join(OUT, "h3_direction.csv"), index=False)
    items = pd.DataFrame(dict(concept=[gloss[c] for c in C3], timucua=[" | ".join(T[c]) for c in C3],
                              sim=[round(M[rows.index(c), cols.index(c)], 3) for c in C3], p_candidate=pT))
    items.sort_values("p_candidate").to_csv(os.path.join(OUT, "h3_timucua_items.csv"), index=False)
    print(h3.to_string())
    print(items.sort_values("p_candidate").head(8).to_string())

    A = pd.DataFrame(tests)
    A.to_csv(os.path.join(OUT, "all_tests.csv"), index=False)
    conf = A[A.role == "CONFIRMATORY"].iloc[0].to_dict()
    summary = dict(confirmatory=conf,
                   secondary_verdicts=A[A.role == "secondary"][["label", "verdict"]].values.tolist(),
                   bh_survivors={L: int(d.C2_survives_BH.sum()) for L, d in cands.items()},
                   possible_candidates={L: d[d.tier == "possible"].concept.tolist() for L, d in cands.items()},
                   uncorrected_p_le_05={L: d[d.p_candidate <= 0.05].concept.tolist() for L, d in cands.items()},
                   h3=h3.to_dict(orient="records"))
    json.dump(summary, open(os.path.join(OUT, "summary.json"), "w"), indent=2, default=lambda x: x.item() if hasattr(x, "item") else str(x))
    print(json.dumps(summary, indent=2, default=lambda x: x.item() if hasattr(x, "item") else str(x)))


if __name__ == "__main__":
    main()
