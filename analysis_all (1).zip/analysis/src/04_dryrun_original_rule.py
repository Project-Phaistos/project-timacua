"""Stages 4-8 of Workstream B, run exactly as pre-registered (prereg/PREREGISTRATION.md).

Outputs in results/:
  stage5_aggregate.csv        every aggregate test (set x measure) with decision fields
  stage5_control_panel.csv    per-control statistics for every test
  candidates_<LANG>.csv       Stage 4 candidate table with p, BH, C1-C7, tier
  h3_direction.csv            H3 tests
  calibration.csv             known-contact calibrations
  exploratory_warao.csv       Timucua vs Warao
  summary.json                headline numbers used in the write-up
"""
import json
import math
import os
from collections import Counter

import numpy as np
import pandas as pd
from scipy.stats import binomtest

from common import (DONOR, MUSKOGEAN, N_PERM, ROOT, SEED, SIMS, bh, concept_forms,
                    load_cldf_forms)
from lingpy.sequence.sound_classes import tokens2class

RES = os.path.join(ROOT, "results")
# dry-run support: a non-Timucua stand-in donor and a separate output folder, to test code paths
DONOR = os.environ.get("DRYRUN_DONOR", DONOR)
OUTD = os.environ.get("RES_OUT", RES)
os.makedirs(OUTD, exist_ok=True)


def cmatrix(rows: dict, cols: dict, measure: str, row_order, col_order):
    f = SIMS[measure]
    M = np.zeros((len(row_order), len(col_order)))
    for i, c in enumerate(row_order):
        for j, d in enumerate(col_order):
            M[i, j] = max(f(a, b) for a in rows[c] for b in cols[d])
    return M


def perm_stats(M, true_cols, seed=SEED, n_perm=N_PERM):
    """M: rows = items (k), cols = all donor concepts (n). true_cols[i] = index of item i's concept."""
    k, n = M.shape
    rng = np.random.default_rng(seed)
    s_obs = M[np.arange(k), true_cols].mean()
    perms = np.argsort(rng.random((n_perm, n)), axis=1)[:, :k]
    null = M[np.arange(k)[None, :], perms].mean(axis=1)
    p = (1 + (null >= s_obs).sum()) / (1 + n_perm)
    return s_obs, null.mean(), s_obs - null.mean(), p


def aggregate_test(name, rec_forms, donor_forms, concepts, measure, controls, all_forms, extra=None):
    dcols = sorted(donor_forms, key=int)
    R = [c for c in concepts if c in rec_forms and c in donor_forms]
    M = cmatrix(rec_forms, donor_forms, measure, R, dcols)
    s, mu, ds, p = perm_stats(M, np.array([dcols.index(c) for c in R]))
    crow = []
    for L in controls:
        lf = all_forms[L]
        RL = [c for c in R if c in lf]
        if len(RL) < max(3, int(0.6 * len(R))):
            continue
        ML = cmatrix(lf, donor_forms, measure, RL, dcols)
        sL, muL, dsL, pL = perm_stats(ML, np.array([dcols.index(c) for c in RL]))
        crow.append(dict(test=name, measure=measure, control=L, n=len(RL), S=sL, null_mean=muL, dS=dsL, p_perm=pL))
    cdf = pd.DataFrame(crow)
    q95 = cdf.dS.quantile(0.95) if len(cdf) else np.nan
    prim = cdf[cdf.control == controls[0]]
    prim_ds = prim.dS.iloc[0] if len(prim) else np.nan
    row = dict(test=name, measure=measure, n_concepts=len(R), S_obs=s, null_mean=mu, dS=ds, p_perm=p,
               primary_control_dS=prim_ds, panel_dS_q95=q95,
               panel_rank_pct=float((cdf.dS < ds).mean()) if len(cdf) else np.nan,
               panel_n=len(cdf), panel_share_p_lt_05=float((cdf.p_perm < 0.05).mean()) if len(cdf) else np.nan,
               rule_a=p < 0.05, rule_b=ds > prim_ds, rule_c=ds > q95)
    row["verdict"] = ("supported" if row["rule_a"] and row["rule_b"] and row["rule_c"]
                      else "inconclusive" if row["rule_a"] and row["rule_b"] else "H0 retained")
    if extra:
        row.update(extra)
    return row, cdf, M, R, dcols


# ------------------------------------------------------------------ C4 phonotactic fit
class BigramLM:
    def __init__(self, words):
        self.c2, self.c1 = Counter(), Counter()
        self.V = set()
        for w in words:
            self.add(w, +1)

    @staticmethod
    def seq(w):
        return ["#"] + list(tokens2class(w.split(), "sca")) + ["$"]

    def add(self, w, sgn):
        s = self.seq(w)
        for a, b in zip(s, s[1:]):
            self.c2[(a, b)] += sgn
            self.c1[a] += sgn
            self.V.add(b)

    def ll(self, w):
        s = self.seq(w)
        V = len(self.V) + 1
        tot = sum(math.log((self.c2[(a, b)] + 1) / (self.c1[a] + V)) for a, b in zip(s, s[1:]))
        return tot / (len(s) - 1)


def main():
    forms = load_cldf_forms()
    forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    params = pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv"))
    gloss = dict(zip(params.ID.astype(str), params.Name))
    langs = sorted(forms.Language_ID.unique())
    allf = {L: concept_forms(forms, L) for L in langs}
    resid = json.load(open(os.path.join(RES, "residue_concepts.json")))
    panel = [c for c in pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID if c != DONOR]
    T = allf[DONOR]

    agg, ctrl = [], []
    keep = {}
    sets = ["MIKASUKI", "MIKASUKI_strict", "MIKASUKI_keep_european_flagged",
            "CREEK", "CREEK_strict", "CREEK_keep_european_flagged"]
    for measure in ["SCA", "NED", "TPG"]:
        for sname in sets:
            L = sname.split("_")[0]
            role = "CONFIRMATORY" if (sname == "MIKASUKI" and measure == "SCA") else "secondary"
            row, cdf, M, R, dcols = aggregate_test(f"{sname} vs Timucua", allf[L], T, resid[sname], measure, panel,
                                                   allf, extra=dict(role=role, residue_set=sname))
            agg.append(row); ctrl.append(cdf)
            if measure == "SCA" and sname in ("MIKASUKI", "CREEK"):
                keep[sname] = (M, R, dcols)
            print(f"{measure:4s} {sname:32s} n={row['n_concepts']:2d} S={row['S_obs']:.3f} dS={row['dS']:+.3f} "
                  f"p={row['p_perm']:.4f} ctrl0={row['primary_control_dS']:+.3f} q95={row['panel_dS_q95']:+.3f} "
                  f"rank={row['panel_rank_pct']:.2f} -> {row['verdict']}", flush=True)

    # ------------------------------------------------ full-list descriptive (no residue filter)
    for L in ["MIKASUKI", "CREEK"]:
        allc = sorted(set(allf[L]) & set(T), key=int)
        row, cdf, *_ = aggregate_test(f"{L} full list vs Timucua (descriptive)", allf[L], T, allc, "SCA", panel, allf,
                                      extra=dict(role="descriptive", residue_set="none"))
        agg.append(row); ctrl.append(cdf)

    # ------------------------------------------------ candidate level, C1-C7, tiers
    mus_words = [s for L in MUSKOGEAN for v in allf[L].values() for s in v]
    lmT = BigramLM([s for v in T.values() for s in v])
    lmM = BigramLM(mus_words)
    s3 = pd.read_csv(os.path.join(RES, "stage3_residue_pool.csv"))
    s3["Parameter_ID"] = s3.Parameter_ID.astype(str)
    cand_all = []
    for L in ["MIKASUKI", "CREEK"]:
        M, R, dcols = keep[L]
        rows = []
        for i, c in enumerate(R):
            j = dcols.index(c)
            obs = M[i, j]
            others = np.delete(M[i], j)
            p = (1 + (others >= obs).sum()) / (1 + len(others))
            rank = int((others > obs).sum()) + 1
            best_pair = max(((SIMS["SCA"](a, b), a, b) for a in allf[L][c] for b in T[c]))
            w = best_pair[1]
            lmM.add(w, -1)  # leave-one-out
            c4_T, c4_M = lmT.ll(w), lmM.ll(w)
            lmM.add(w, +1)
            top_other = dcols[int(np.argmax(np.where(np.arange(len(dcols)) == j, -9, M[i])))]
            rows.append(dict(language=L, concept=gloss[c], parameter_id=c, recipient_form=w, timucua_form=best_pair[2],
                             sim=round(obs, 3), rank_among_timucua_concepts=rank, n_timucua_concepts=len(dcols),
                             p_candidate=round(p, 4), best_other_concept=gloss[top_other],
                             best_other_sim=round(float(np.max(others)), 3),
                             loglik_timucua=round(c4_T, 3), loglik_muskogean=round(c4_M, 3)))
        df = pd.DataFrame(rows)
        rej, padj = bh(df.p_candidate.values, 0.05)
        df["p_bh"] = np.round(padj, 4)
        df["C1_no_muskogean_etymology"] = True
        df["C2_survives_BH"] = rej
        df["C3_semantic_fit"] = True
        df["C4_phonotactic_fit_timucua"] = df.loglik_timucua > df.loglik_muskogean
        df["C5_opacity"] = "unassessed (expert)"
        df["C6_chronology"] = "unassessed (needs Hitchiti)"
        flagged = set(s3[(s3.Language_ID == L) & s3.european_flag].Parameter_ID)
        df["C7_not_european"] = ~df.parameter_id.isin(flagged)
        met = (df.C1_no_muskogean_etymology.astype(int) + df.C2_survives_BH.astype(int) + df.C3_semantic_fit.astype(int)
               + df.C4_phonotactic_fit_timucua.astype(int) + df.C7_not_european.astype(int))
        df["criteria_met_of_assessable_5"] = met
        df["tier"] = np.where((met >= 6) & df.C2_survives_BH, "strong",
                              np.where(df.C1_no_muskogean_etymology & df.C3_semantic_fit & df.C4_phonotactic_fit_timucua
                                       & df.C7_not_european & (df.p_candidate <= 0.05), "possible", "rejected"))
        df = df.sort_values("p_candidate")
        df.to_csv(os.path.join(OUTD, f"candidates_{L.lower()}.csv"), index=False)
        cand_all.append(df)
        print(df[["concept", "recipient_form", "timucua_form", "sim", "rank_among_timucua_concepts", "p_candidate",
                  "p_bh", "C4_phonotactic_fit_timucua", "tier"]].to_string())

    # ------------------------------------------------ H3 direction
    cog = pd.read_csv(os.path.join(RES, "stage2_muskogean_cognates.csv"))
    cog["Parameter_ID"] = cog.Parameter_ID.astype(str)
    wide = cog.groupby("lexstatid").Language_ID.nunique()
    wide_ids = set(wide[wide >= 3].index)
    inh = {}
    for r in cog[cog.lexstatid.isin(wide_ids)].itertuples():
        inh.setdefault(r.Parameter_ID, []).append(r.Segments)
    inh = {c: sorted(set(v)) for c, v in inh.items()}
    h3rows = []
    Tc = sorted(set(T) & set(inh), key=int)
    row, cdf, M3, R3, d3 = aggregate_test("Timucua vs widespread Muskogean sets (M->T)", T, inh, Tc, "SCA", panel, allf,
                                          extra=dict(role="H3", residue_set="widespread>=3"))
    agg.append(row); ctrl.append(cdf)
    pT = []
    for i, c in enumerate(R3):
        j = d3.index(c)
        pT.append((1 + (np.delete(M3[i], j) >= M3[i, j]).sum()) / len(d3))
    pR = list(pd.concat(cand_all).p_candidate)
    kT, nT = int(sum(p <= 0.05 for p in pT)), len(pT)
    kR, nR = int(sum(p <= 0.05 for p in pR)), len(pR)
    h3rows.append(dict(direction="Muskogean->Timucua (Timucua items vs widespread Muskogean sets)", n=nT, k_p_le_05=kT,
                       rate=round(kT / nT, 3), binom_p_vs_5pct=binomtest(kT, nT, 0.05, alternative="greater").pvalue,
                       aggregate_p_perm=row["p_perm"], aggregate_dS=row["dS"], panel_q95=row["panel_dS_q95"],
                       rule_a=row["rule_a"], rule_c=row["rule_c"]))
    h3rows.append(dict(direction="Timucua->Muskogean (Mikasuki+Creek residue vs Timucua)", n=nR, k_p_le_05=kR,
                       rate=round(kR / nR, 3), binom_p_vs_5pct=binomtest(kR, nR, 0.05, alternative="greater").pvalue))
    h3 = pd.DataFrame(h3rows)
    h3["H3_supported"] = bool(row["rule_a"] and row["rule_c"] and (kT / nT > kR / nR))
    h3.to_csv(os.path.join(OUTD, "h3_direction.csv"), index=False)
    m3 = pd.DataFrame(dict(concept=[gloss[c] for c in R3], timucua=[" | ".join(T[c]) for c in R3],
                           muskogean=[" | ".join(inh[c][:3]) for c in R3], sim=[M3[i, d3.index(c)] for i, c in enumerate(R3)],
                           p_candidate=pT)).sort_values("p_candidate")
    m3.to_csv(os.path.join(OUTD, "h3_timucua_items.csv"), index=False)
    print(h3.to_string()); print(m3.head(8).to_string())

    # ------------------------------------------------ calibration and exploratory
    cal = []
    for a, b in [("MOBILIAN_JARGON", "CHOCTAW"), ("YUCHI", "CREEK"), ("NATCHEZ", "CREEK"), ("WARAO", "TIMUCUA"),
                 ("MIKASUKI", "CREEK"), ("KOASATI", "ALABAMA")]:
        shared = sorted(set(allf[a]) & set(allf[b]), key=int)
        row, cdf, *_ = aggregate_test(f"{a} vs {b}", allf[a], allf[b], shared, "SCA", panel, allf,
                                      extra=dict(role="calibration" if b != "TIMUCUA" else "exploratory",
                                                 residue_set="all shared concepts"))
        cal.append(row); ctrl.append(cdf)
        print(f"{a} vs {b}: n={row['n_concepts']} dS={row['dS']:+.3f} p={row['p_perm']:.4f} q95={row['panel_dS_q95']:+.3f} "
              f"rank={row['panel_rank_pct']:.2f}")
    pd.DataFrame(cal).to_csv(os.path.join(OUTD, "calibration.csv"), index=False)

    A = pd.DataFrame(agg)
    A.to_csv(os.path.join(OUTD, "stage5_aggregate.csv"), index=False)
    pd.concat(ctrl).to_csv(os.path.join(OUTD, "stage5_control_panel.csv"), index=False)
    conf = A[A.role == "CONFIRMATORY"].iloc[0].to_dict()
    summary = dict(confirmatory={k: (bool(v) if isinstance(v, (bool, np.bool_)) else v) for k, v in conf.items()},
                   n_bh_survivors={L: int(d.C2_survives_BH.sum()) for L, d in zip(["MIKASUKI", "CREEK"], cand_all)},
                   possible_candidates={L: list(d[d.tier == "possible"].concept) for L, d in zip(["MIKASUKI", "CREEK"], cand_all)},
                   h3_supported=bool(h3.H3_supported.iloc[0]))
    json.dump(summary, open(os.path.join(OUTD, "summary.json"), "w"), indent=2, default=float)
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
