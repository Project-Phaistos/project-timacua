"""Addendum 1 (prereg/ADDENDUM_1_APALACHEE.md): H4 calibration with Apalachee.

Apalachee forms: Kimball (1988), An Apalachee Vocabulary, IJAL 54: 387-398 (phonemic
retranscriptions), mapped to the ASJP 100-item concepts in cldf_addendum/apalachee_forms.csv.

Steps
  A  Stage 2 check: automated cognate detection (LexStat + SCA, as frozen) on the six Muskogean
     lists plus Apalachee, scored against Kimball's expert cognate judgments.
  B  H4 two-way test: Apalachee (row) x Timucua (column) over every Apalachee concept Timucua
     attests; same panel, measure (SCA) and rule set A as the frozen H2 test.
  C  Mikasuki x Timucua over the same concept set, for the H4 comparison of effect sizes.
  D  Per-concept candidate p-values for Apalachee forms against Timucua (descriptive).
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from lingpy.compare.lexstat import LexStat

sys.path.insert(0, os.path.dirname(__file__))
import importlib.util  # noqa: E402

from common import MUSKOGEAN, ROOT, SEED, concept_forms, load_cldf_forms, sim_sca  # noqa: E402
from twoway import get, summarize, twoway  # noqa: E402

spec = importlib.util.spec_from_file_location("grid", os.path.join(os.path.dirname(__file__), "05_similarity_grid.py"))
grid = importlib.util.module_from_spec(spec); spec.loader.exec_module(grid)

OUT = os.path.join(ROOT, "results", "h4_apalachee")
os.makedirs(OUT, exist_ok=True)


def main():
    ap = pd.read_csv(os.path.join(ROOT, "cldf_addendum", "apalachee_forms.csv"))
    ap["Parameter_ID"] = ap.Parameter_ID.astype(str)
    forms = load_cldf_forms(); forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    params = pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv"))
    gloss = dict(zip(params.ID.astype(str), params.Name))
    allf = grid.all_forms()
    allf["APALACHEE"] = {c: list(g.Segments) for c, g in ap.groupby("Parameter_ID")}

    # ---------------------------------------------------------------- A. Stage 2 against Kimball
    mus = forms[forms.Language_ID.isin(MUSKOGEAN)]
    D = {0: ["doculect", "concept", "ipa", "tokens", "src"]}
    k = 1
    for r in mus.itertuples():
        D[k] = [r.Language_ID, r.Parameter_ID, r.Segments.replace(" ", ""), r.Segments.split(), r.ID]; k += 1
    for r in ap.itertuples():
        D[k] = ["APALACHEE", r.Parameter_ID, r.Segments.replace(" ", ""), r.Segments.split(), r.Form]; k += 1
    lex = LexStat(D, check=True, segments="tokens")
    lex.get_scorer(runs=1000)
    lex.cluster(method="lexstat", threshold=0.55, cluster_method="infomap", ref="lexstatid")
    lex.cluster(method="sca", threshold=0.45, ref="scaid")
    rows = [dict(doculect=lex[i, "doculect"], concept=lex[i, "concept"], src=lex[i, "src"],
                 lexstatid=lex[i, "lexstatid"], scaid=lex[i, "scaid"]) for i in lex]
    cg = pd.DataFrame(rows)
    a = cg[cg.doculect == "APALACHEE"].copy()

    def has_partner(r, ref):
        return bool(((cg[ref] == r[ref]) & (cg.doculect != "APALACHEE")).any())

    a["auto_inherited"] = a.apply(lambda r: has_partner(r, "lexstatid") or has_partner(r, "scaid"), axis=1)
    a = a.merge(ap[["Form", "Kimball_cognates"]], left_on="src", right_on="Form")
    a["expert_inherited"] = ~a.Kimball_cognates.str.startswith("no")
    a["gloss"] = a.concept.map(gloss)
    a.to_csv(os.path.join(OUT, "stage2_vs_kimball.csv"), index=False)
    tp = int((a.auto_inherited & a.expert_inherited).sum()); fn = int((~a.auto_inherited & a.expert_inherited).sum())
    fp = int((a.auto_inherited & ~a.expert_inherited).sum()); tn = int((~a.auto_inherited & ~a.expert_inherited).sum())
    stage2 = dict(items=len(a), expert_inherited=int(a.expert_inherited.sum()), auto_inherited=int(a.auto_inherited.sum()),
                  agree_inherited=tp, missed_cognates=fn, false_cognates=fp, agree_residue=tn,
                  recall_of_expert_cognates=round(tp / max(1, tp + fn), 3))
    print("Stage 2 vs Kimball:", stage2, flush=True)

    # ---------------------------------------------------------------- grid pairs for Apalachee
    panel = list(pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID)
    for B in panel + ["TIMUCUA", "MIKASUKI"]:
        grid.pair_job(("APALACHEE", B, allf["APALACHEE"], allf[B]))

    langs = pd.read_csv(os.path.join(ROOT, "cldf", "languages.csv"))
    macro = dict(zip(langs.ID, langs.Macroarea)); macro["APALACHEE"] = "North America"
    T = allf["TIMUCUA"]
    C = sorted([c for c in allf["APALACHEE"] if c in T], key=int)

    # ---------------------------------------------------------------- B. H4 two-way test
    def verdict(s):
        A_ = s["focal_p_perm"] < 0.05 and s["focal_p_max"] < 0.05
        B_ = s["focal_p_perm"] < 0.05 and s["focal_dS"] > s["primary_control_dS"] and s["focal_dS"] > s["recipient_panel_q95_dS"]
        s.update(ruleset_A=A_, ruleset_B=B_, verdict="supported" if A_ and B_ else "inconclusive" if (A_ or B_) else "H0 retained")
        return s

    dfA = twoway("APALACHEE", "TIMUCUA", C, "SCA", panel, macro)
    dfA.to_csv(os.path.join(OUT, "twoway_APALACHEE_x_TIMUCUA.csv"), index=False)
    sA = verdict(summarize(dfA, "APALACHEE", "TIMUCUA"))
    dfM = twoway("MIKASUKI", "TIMUCUA", C, "SCA", panel, macro)
    dfM.to_csv(os.path.join(OUT, "twoway_MIKASUKI_x_TIMUCUA_same_concepts.csv"), index=False)
    sM = verdict(summarize(dfM, "MIKASUKI", "TIMUCUA"))
    h4 = dict(concepts=[gloss[c] for c in C], n=len(C),
              apalachee=sA, mikasuki_same_concepts=sM,
              H4_supported=bool(sA["ruleset_A"] and sA["focal_dS"] > sM["focal_dS"]))

    # ---------------------------------------------------------------- D. candidates
    rows_, cols_, M = get("APALACHEE", "TIMUCUA", "SCA")
    cands = []
    for c in C:
        i, j = rows_.index(c), cols_.index(c)
        obs = M[i, j]; others = np.delete(M[i], j)
        best = max((sim_sca(x, y), x, y) for x in allf["APALACHEE"][c] for y in T[c])
        cands.append(dict(concept=gloss[c], apalachee=best[1].replace(" ", ""), timucua=best[2].replace(" ", ""),
                          sim=round(obs, 3), rank=int((others > obs).sum()) + 1, n_timucua=len(cols_),
                          p_candidate=round((1 + (others >= obs).sum()) / (1 + len(others)), 4),
                          expert_residue=bool(ap[(ap.Parameter_ID == c)].Kimball_cognates.str.startswith("no").all())))
    cd = pd.DataFrame(cands).sort_values("p_candidate")
    cd.to_csv(os.path.join(OUT, "apalachee_candidates.csv"), index=False)
    h4["candidates_p_le_05"] = cd[cd.p_candidate <= 0.05].concept.tolist()
    h4["stage2_vs_kimball"] = stage2
    json.dump(h4, open(os.path.join(OUT, "h4_summary.json"), "w"), indent=2,
              default=lambda x: x.item() if hasattr(x, "item") else str(x))
    keys = ["focal_n_items", "focal_dS", "focal_z", "focal_p_perm", "focal_p_row", "focal_p_col", "focal_p_max",
            "primary_control_dS", "verdict"]
    print("APALACHEE x TIMUCUA:", {k: sA[k] for k in keys})
    print("MIKASUKI x TIMUCUA (same concepts):", {k: sM[k] for k in keys})
    print("H4 supported:", h4["H4_supported"])
    print(cd.to_string())


if __name__ == "__main__":
    main()
