"""Assign the 100 ASJP concepts to 5 strata for stratified permutation (Concepticon fields):
action (Action/Process), body (semantic field 'The body', non-verbs), thing (other Person/Thing),
property (Property), other (pronouns, numerals, function words)."""
import os
import pandas as pd
from common import EXT, ROOT

cc = pd.read_csv(os.path.join(EXT, "concepticon-data", "concepticondata", "concepticon.tsv"), sep="\t")
p = pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv"))
m = p.merge(cc[["ID", "SEMANTICFIELD", "ONTOLOGICAL_CATEGORY"]], left_on="Concepticon_ID", right_on="ID", how="left",
            suffixes=("", "_cc"))


def stratum(r):
    if r.ONTOLOGICAL_CATEGORY == "Action/Process":
        return "action"
    if r.SEMANTICFIELD == "The body":
        return "body"
    return {"Person/Thing": "thing", "Property": "property"}.get(r.ONTOLOGICAL_CATEGORY, "other")


m["stratum"] = m.apply(stratum, axis=1)
m[["ID", "Name", "Concepticon_ID", "SEMANTICFIELD", "ONTOLOGICAL_CATEGORY", "stratum"]].to_csv(
    os.path.join(ROOT, "cldf", "concept_strata.csv"), index=False)
print(m.stratum.value_counts().to_dict())
for s, g in m.groupby("stratum"):
    print(s, ", ".join(g.Name))
