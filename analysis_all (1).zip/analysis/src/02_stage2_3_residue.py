"""Stages 2-3: Muskogean-internal cognate detection and the residue pool.

Stage 2  LexStat (List 2012) on the six Muskogean lists, infomap clustering at t=0.55,
         plus SCA clustering at t=0.45 as a second, more lenient pass. A recipient
         item is INHERITED if either method puts it in a cognate set with any other
         Muskogean language.
Stage 3  Residue items are compared with the Spanish and English forms for the same
         concept; an item whose SCA similarity to a European form is >= 0.55
         (i.e. SCA distance <= 0.45, the same cut used for Muskogean cognacy) is flagged
         and removed as a possible European loan.
No Timucua data are touched here.
"""
import json
import os

import numpy as np
import pandas as pd
from lingpy import Wordlist as LPWordlist
from lingpy.compare.lexstat import LexStat

from common import MUSKOGEAN, RECIPIENTS, ROOT, SEED, load_cldf_forms, sim_sca

import random
STRICT_CUT = 0.40  # sensitivity: drop residue items with SCA sim >= 0.40 to any same-concept Muskogean form
random.seed(SEED)


def main():
    forms = load_cldf_forms()
    params = pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv"))
    gloss = dict(zip(params.ID.astype(str), params.Name))
    forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    mus = forms[forms.Language_ID.isin(MUSKOGEAN)].reset_index(drop=True)

    D = {0: ["doculect", "concept", "ipa", "tokens", "form_id"]}
    for i, r in mus.iterrows():
        D[i + 1] = [r.Language_ID, r.Parameter_ID, r.Segments.replace(" ", ""), r.Segments.split(), r.ID]
    lex = LexStat(D, check=True, segments="tokens")
    lex.get_scorer(runs=1000)
    lex.cluster(method="lexstat", threshold=0.55, cluster_method="infomap", ref="lexstatid")
    lex.cluster(method="sca", threshold=0.45, ref="scaid")

    rows = []
    for idx in lex:
        rows.append(dict(Form_ID=lex[idx, "form_id"], Language_ID=lex[idx, "doculect"],
                         Parameter_ID=lex[idx, "concept"], Segments=" ".join(lex[idx, "tokens"]),
                         lexstatid=lex[idx, "lexstatid"], scaid=lex[idx, "scaid"]))
    cog = pd.DataFrame(rows)
    cog.to_csv(os.path.join(ROOT, "results", "stage2_muskogean_cognates.csv"), index=False)

    def partners(row, ref):
        grp = cog[(cog[ref] == row[ref])]
        return sorted(set(grp.Language_ID) - {row.Language_ID})

    cog["lexstat_partners"] = cog.apply(lambda r: ";".join(partners(r, "lexstatid")), axis=1)
    cog["sca_partners"] = cog.apply(lambda r: ";".join(partners(r, "scaid")), axis=1)
    cog["inherited"] = (cog.lexstat_partners != "") | (cog.sca_partners != "")

    # residue per Muskogean language (descriptive; recipients are the ones that matter)
    resid_rate = cog.groupby("Language_ID").apply(
        lambda g: pd.Series(dict(items=len(g), concepts=g.Parameter_ID.nunique(),
                                 residue_items=int((~g.inherited).sum()),
                                 residue_concepts=int(g.groupby("Parameter_ID").inherited.any().eq(False).sum()))))
    resid_rate["residue_concept_rate"] = (resid_rate.residue_concepts / resid_rate.concepts).round(3)
    resid_rate.to_csv(os.path.join(ROOT, "results", "stage2_residue_rates_by_language.csv"))

    # ---------------------------------------------------------------- Stage 3
    eur = forms[forms.Language_ID.isin(["SPANISH", "ENGLISH"])]
    out = {}
    allrows = []
    for L in RECIPIENTS:
        g = cog[cog.Language_ID == L].copy()
        # a concept counts as residue only if NONE of the recipient's forms for it is inherited
        concept_inh = g.groupby("Parameter_ID").inherited.any()
        g = g[g.Parameter_ID.map(concept_inh) == False].copy()
        flags = []
        for r in g.itertuples():
            e = eur[eur.Parameter_ID == r.Parameter_ID]
            best = max([(sim_sca(r.Segments, s), lang, s) for lang, s in zip(e.Language_ID, e.Segments)],
                       default=(0, "", ""))
            flags.append(best)
        g["eur_best_sim"] = [round(b[0], 3) for b in flags]
        g["eur_best_lang"] = [b[1] for b in flags]
        g["eur_best_form"] = [b[2] for b in flags]
        g["european_flag"] = g.eur_best_sim >= 0.55
        g["gloss"] = g.Parameter_ID.map(gloss)
        # sensitivity: closest same-concept form anywhere else in Muskogean
        mus_best = []
        for r in g.itertuples():
            o = mus[(mus.Parameter_ID == r.Parameter_ID) & (mus.Language_ID != L)]
            mus_best.append(max([(sim_sca(r.Segments, s), lang, s) for lang, s in zip(o.Language_ID, o.Segments)],
                                default=(0, "", "")))
        g["mus_best_sim"] = [round(b[0], 3) for b in mus_best]
        g["mus_best_lang"] = [b[1] for b in mus_best]
        g["mus_best_form"] = [b[2] for b in mus_best]
        # Stage 2b: check against published reconstructions (Booker 2005 Proto-Muskogean, via ASJP)
        pm = forms[forms.Language_ID == "PROTO_MUSKOGEAN"]
        pmb = []
        for r in g.itertuples():
            o = pm[pm.Parameter_ID == r.Parameter_ID]
            pmb.append(max([(sim_sca(r.Segments, s), s) for s in o.Segments], default=(np.nan, "")))
        g["pm_sim"] = [round(b[0], 3) if b[0] == b[0] else np.nan for b in pmb]
        g["pm_form"] = [b[1] for b in pmb]
        g["pm_match"] = g.pm_sim >= 0.55
        g["strict_residue"] = (~g.european_flag) & (~g.pm_match) & (g.mus_best_sim < STRICT_CUT)
        allrows.append(g)
        keep = g[(~g.european_flag) & (~g.pm_match)]
        out[L] = sorted(set(keep.Parameter_ID), key=int)
        out[L + "_strict"] = sorted(set(g[g.strict_residue].Parameter_ID), key=int)
        out[L + "_keep_european_flagged"] = sorted(set(g[~g.pm_match].Parameter_ID), key=int)
    res = pd.concat(allrows)
    res.to_csv(os.path.join(ROOT, "results", "stage3_residue_pool.csv"), index=False)
    json.dump(out, open(os.path.join(ROOT, "results", "residue_concepts.json"), "w"), indent=1)
    print(resid_rate)
    for L in RECIPIENTS:
        print(L, len(out[L]), "residue concepts")
        print(res[res.Language_ID == L][["Parameter_ID", "gloss", "Segments", "eur_best_sim", "european_flag", "mus_best_sim", "mus_best_form", "pm_sim", "pm_form", "strict_residue"]].to_string())


if __name__ == "__main__":
    main()
