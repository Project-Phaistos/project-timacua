"""Stage 1: build the pilot CLDF wordlist from public sources.

Sources (pinned commits are written to cldf/provenance.json):
  ASJP (lexibank/asjp)  100-item lists for Timucua, Muskogean, calibration and control languages
  Concepticon           concept metadata

Also selects the control-language panel by the pre-registered rule (no Timucua
similarity is computed here).
"""
import json
import os
import subprocess

import numpy as np
import pandas as pd
from pycldf import Wordlist

from common import EXT, ROOT, normalize_segments, cv_profile

ASJP = os.path.join(EXT, "asjp", "cldf")

CORE = ["TIMUCUA", "MIKASUKI", "CREEK", "CHOCTAW", "CHICKASAW", "ALABAMA", "KOASATI"]
CALIBRATION = ["YUCHI", "NATCHEZ", "MOBILIAN_JARGON"]  # known contact with Creek / Choctaw
SPECIAL = ["WARAO"]  # Granberry's proposed relative, tested separately
EUROPEAN = ["SPANISH", "ENGLISH"]  # Stage 3 loan filter
RECONSTRUCTION = ["PROTO_MUSKOGEAN"]  # Booker (2005) via ASJP: Stage 2 cross-check against published reconstructions

# Families proposed as relatives of Timucua (paper section 2.2) plus European donors
EXCLUDED_FAMILIES = {
    "Muskogean", "Algic", "Siouan", "Cariban", "Arawakan", "Chibchan", "Warao", "Timucua",
    "Indo-European", "Pidgin", "Bookkeeping", "Speech Register", "Artificial Language",
    "Unclassifiable",
}
N_PANEL = 50
MIN_CONCEPTS = 90


def git_rev(path):
    try:
        return subprocess.check_output(["git", "-C", path, "log", "-1", "--format=%H %cI"]).decode().strip()
    except Exception:
        return "unknown"


def profile(seglists):
    lens, vfinal, vprop, clus, inv = [], [], [], [], set()
    for toks in seglists:
        if not toks:
            continue
        cv = cv_profile(toks)
        lens.append(len(toks))
        vfinal.append(cv[-1] == "V")
        vprop.append(cv.count("V") / len(cv))
        runs = [len(r) for r in cv.replace("T", "").split("V") if r]
        clus.append(np.mean(runs) if runs else 0.0)
        inv.update(toks)
    return dict(mean_len=np.mean(lens), v_final=np.mean(vfinal), v_prop=np.mean(vprop),
                c_cluster=np.mean(clus), inventory=len(inv))


def main():
    langs = pd.read_csv(os.path.join(ASJP, "languages.csv"), low_memory=False)
    forms = pd.read_csv(os.path.join(ASJP, "forms.csv"), low_memory=False)
    params = pd.read_csv(os.path.join(ASJP, "parameters.csv"))
    forms = forms[forms.Parameter_ID.astype(str).str.fullmatch(r"\d+")]
    forms["Parameter_ID"] = forms.Parameter_ID.astype(int)
    forms = forms[forms.Parameter_ID <= 100]
    fam = dict(zip(langs.ID, langs.Family))
    fam["PROTO_MUSKOGEAN"] = "Muskogean"

    # ------------------------------------------------------------------ normalization
    log = []
    norm = []
    for r in forms.itertuples():
        toks = normalize_segments(r.Segments, fam.get(r.Language_ID), r.Language_ID)
        new = " ".join(toks)
        if new != r.Segments:
            rules = []
            if "ɐ" in r.Segments:
                rules.append("R1 ɐ->a")
            if "ʎ" in r.Segments and fam.get(r.Language_ID) == "Muskogean":
                rules.append("R2 ʎ->ɬ (Muskogean)")
            if any(x in r.Segments.split() for x in ["+", "_", "#"]):
                rules.append("R3 drop boundary markers")
            if r.Language_ID == "CREEK" and r.Segments.split()[-3:] == ["i", "t", "ɐ"] and len(toks) == len(r.Segments.split()) - 3:
                rules.append("R4 strip Creek infinitive -ita")
            log.append((r.ID, r.Language_ID, r.Parameter_ID, r.Value, r.Segments, new, "; ".join(rules)))
        norm.append(new)
    forms = forms.assign(Segments=norm)
    forms = forms[forms.Segments.str.len() > 0]

    # ------------------------------------------------------------------ control panel
    nconc = forms.groupby("Language_ID").Parameter_ID.nunique()
    langs["n_concepts"] = langs.ID.map(nconc).fillna(0).astype(int)
    pool = langs[(langs.Macroarea != "North America") & (~langs.Family.isin(EXCLUDED_FAMILIES))
                 & langs.Family.notna() & (~langs.long_extinct.astype(bool))
                 & (langs.n_concepts >= MIN_CONCEPTS) & langs.Glottocode.notna()].copy()
    seg_by_lang = {L: [s.split() for s in g.Segments] for L, g in forms.groupby("Language_ID")}
    feats = pd.DataFrame({L: profile(seg_by_lang[L]) for L in list(pool.ID) + ["MIKASUKI", "TIMUCUA"]}).T
    z = (feats - feats.loc[pool.ID].mean()) / feats.loc[pool.ID].std()
    pool["dist_to_mikasuki"] = pool.ID.map(lambda L: float(np.linalg.norm(z.loc[L] - z.loc["MIKASUKI"])))
    best = pool.sort_values("dist_to_mikasuki").groupby("Family").head(1)
    panel = best.sort_values("dist_to_mikasuki").head(N_PANEL)
    primary = panel.iloc[0].ID
    panel_ids = list(panel.ID)
    feats.round(4).to_csv(os.path.join(ROOT, "cldf", "phonotactic_profiles.csv"))
    panel[["ID", "Name", "Glottocode", "Family", "Macroarea", "n_concepts", "dist_to_mikasuki"]].to_csv(
        os.path.join(ROOT, "cldf", "control_panel.csv"), index=False)

    selected = CORE + CALIBRATION + SPECIAL + EUROPEAN + RECONSTRUCTION + panel_ids
    role = {L: "core" for L in CORE}
    role.update({L: "calibration" for L in CALIBRATION})
    role.update({L: "special" for L in SPECIAL})
    role.update({L: "european" for L in EUROPEAN})
    role.update({L: "reconstruction" for L in RECONSTRUCTION})
    role.update({L: "control" for L in panel_ids})
    role[primary] = "control_primary"
    role["TIMUCUA"] = "donor_candidate"
    role["MIKASUKI"] = role["CREEK"] = "recipient"

    sub = forms[forms.Language_ID.isin(selected)].copy()
    lsub = langs[langs.ID.isin(selected)].copy()
    lsub["Role"] = lsub.ID.map(role)

    # ------------------------------------------------------------------ write CLDF
    ds = Wordlist.in_dir(os.path.join(ROOT, "cldf"))
    ds.add_component("LanguageTable", "Family", "Role")
    ds.add_component("ParameterTable", "Concepticon_ID", "Concepticon_Gloss")
    ds.add_columns("FormTable", "Asjp_Value", "Original_Segments")
    srcids = {s for s in sub.Source.astype(str)}
    from pycldf.sources import Source
    import re
    bib = open(os.path.join(ASJP, "sources.bib"), encoding="utf8").read()
    sources = []
    entries = {}
    for chunk in bib.split("@misc{")[1:]:
        key = chunk.split(",", 1)[0].strip()
        fields = dict(re.findall(r"^\s*(\w+) = \{(.*)\},?\s*$", chunk, re.M))
        entries[key] = fields
    for sid in sorted(srcids):
        e = entries.get(sid)
        if e:
            clean = {k: v.replace("{", "").replace("}", "") for k, v in e.items()}
            sources.append(Source("misc", "asjp" + sid, **clean))
    ds.add_sources(*sources)
    orig = dict(zip(forms.ID, pd.read_csv(os.path.join(ASJP, "forms.csv"), low_memory=False).set_index("ID").loc[forms.ID].Segments))
    ds.write(
        LanguageTable=[{k: (None if (isinstance(v, float) and np.isnan(v)) else v) for k, v in
                        dict(ID=r.ID, Name=r.Name, Glottocode=r.Glottocode, Latitude=r.Latitude,
                             Longitude=r.Longitude, Family=r.Family if r.ID != "PROTO_MUSKOGEAN" else "Muskogean",
                             Macroarea=r.Macroarea if r.ID != "PROTO_MUSKOGEAN" else "North America", Role=r.Role).items()}
                       for r in lsub.itertuples()],
        ParameterTable=[dict(ID=str(r.ID), Name=r.Name.lstrip("*"), Concepticon_ID=str(r.Concepticon_ID),
                             Concepticon_Gloss=r.Concepticon_Gloss) for r in params.itertuples() if int(r.ID) <= 100],
        FormTable=[dict(ID=r.ID, Language_ID=r.Language_ID, Parameter_ID=str(r.Parameter_ID), Value=r.Value,
                        Form=r.Form, Segments=r.Segments.split(), Source=["asjp" + str(r.Source)],
                        Asjp_Value=r.Value, Original_Segments=orig.get(r.ID, ""))
                   for r in sub.itertuples()],
    )
    nl = pd.DataFrame(log, columns=["Form_ID", "Language_ID", "Parameter_ID", "ASJP_Value", "Segments_before", "Segments_after", "Rule"])
    nl[nl.Language_ID.isin(selected)].to_csv(os.path.join(ROOT, "cldf", "normalization_log.csv"), index=False)

    prov = {
        "asjp": git_rev(os.path.join(EXT, "asjp")),
        "wold": git_rev(os.path.join(EXT, "wold")),
        "ids": git_rev(os.path.join(EXT, "ids")),
        "wals": git_rev(os.path.join(EXT, "wals")),
        "concepticon": git_rev(os.path.join(EXT, "concepticon-data")),
        "control_rule": dict(excluded_families=sorted(EXCLUDED_FAMILIES), excluded_macroarea="North America",
                             min_concepts=MIN_CONCEPTS, one_per_family=True, n_panel=N_PANEL,
                             profile_features=list(feats.columns), matched_to="MIKASUKI"),
        "primary_control": primary,
    }
    json.dump(prov, open(os.path.join(ROOT, "cldf", "provenance.json"), "w"), indent=2)
    print("languages:", len(lsub), "forms:", len(sub), "primary control:", primary)
    print(panel[["ID", "Family", "Macroarea", "n_concepts", "dist_to_mikasuki"]].head(12).to_string())
    print(feats.loc[["MIKASUKI", "TIMUCUA", primary]].round(3))
    print("normalization changes:", len(nl[nl.Language_ID.isin(selected)]))


if __name__ == "__main__":
    main()
