"""Pre-freeze: compare unstratified vs stratified permutation (within 5 semantic strata)
on the placebo grid and the calibrations. No Timucua data."""
import json, os
import pandas as pd
from common import ROOT, load_cldf_forms
from twoway import load_strata, summarize, twoway

OUT = os.path.join(ROOT, "validation")
langs = pd.read_csv(os.path.join(ROOT, "cldf", "languages.csv"))
macro = dict(zip(langs.ID, langs.Macroarea)); macro["MUSK_INHERITED"] = "North America"
panel = list(pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID)
forms = load_cldf_forms(); forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
tc = set(forms[forms.Language_ID == "TIMUCUA"].Parameter_ID)
resid = json.load(open(os.path.join(ROOT, "results", "residue_concepts.json")))
strata = load_strata()
rows = []
for L in ["MIKASUKI", "CREEK"]:
    C = [c for c in resid[L] if c in tc]
    df = twoway(L, None, C, "SCA", panel, macro, strata=strata)
    df.to_csv(os.path.join(OUT, f"placebo_{L}_SCA_stratified.csv"), index=False)
    s = summarize(df, L, None); s.update(analysis=f"placebo stratified: {L}", n_concepts=len(C)); rows.append(s); print(s, flush=True)
    top = df[df.row == L].sort_values("interaction", ascending=False).head(4)
    print(top[["col", "z", "p_perm", "interaction", "p_twoway"]].to_string(), flush=True)
for a, b in [("MOBILIAN_JARGON", "CHOCTAW"), ("MIKASUKI", "CREEK"), ("KOASATI", "ALABAMA"), ("YUCHI", "CREEK"),
             ("NATCHEZ", "CREEK"), ("MIKASUKI", "AFAR_3"), ("CREEK", "AFAR_3")]:
    fa = set(forms[forms.Language_ID == a].Parameter_ID); fb = set(forms[forms.Language_ID == b].Parameter_ID)
    C = sorted(fa & fb, key=int)
    df = twoway(a, b, C, "SCA", panel, macro, strata=strata)
    s = summarize(df, a, b); s.update(analysis=f"calibration stratified: {a} x {b}", n_concepts=len(C)); rows.append(s)
    print({k: s[k] for k in ["analysis", "focal_z", "focal_p_perm", "focal_p_twoway", "fpr_new_rule_all_cells", "perm_only_fpr_all_cells"]}, flush=True)
pd.DataFrame(rows).to_csv(os.path.join(OUT, "placebo_and_calibration_stratified.csv"), index=False)
