"""Batched SCA similarity with per-form preprocessing cached. Numerically identical to
common.sim_sca (checked in tests); about an order of magnitude faster for large grids."""
import functools
import logging
logging.disable(logging.INFO)
from lingpy import rc
from lingpy.settings import rcParams
from lingpy.algorithm import calign
from lingpy.sequence.sound_classes import tokens2class, prosodic_string, prosodic_weights

_MODEL = rcParams["sca"]
_KW = dict(diacritics=rcParams["diacritics"], vowels=rcParams["vowels"], tones=rcParams["tones"],
           combiners=rcParams["combiners"], breaks=rcParams["breaks"], stress=rcParams["stress"],
           merge_vowels=rcParams["merge_vowels"])


@functools.lru_cache(maxsize=None)
def prep(form: str):
    from lingpy.sequence.sound_classes import ipa2tokens
    toks = form.split() if " " in form else ipa2tokens(form, **_KW)
    cls = tokens2class(toks, _MODEL, stress=rcParams["stress"])
    pro = prosodic_string(toks, **_KW)
    w = prosodic_weights(pro, _transform=rcParams["align_transform"])
    return cls, w, pro


def sims(pairs):
    """pairs: list of (formA, formB) segment strings -> list of similarities (1 - SCA distance)."""
    if not pairs:
        return []
    P = [(prep(a), prep(b)) for a, b in pairs]
    out = calign.align_pairs([(x[0], y[0]) for x, y in P], [(x[1], y[1]) for x, y in P],
                             [(x[2], y[2]) for x, y in P], -1, 0.5, 0.3, _MODEL.scorer, "global", "T_", distance=1)
    return [1.0 - r[2] for r in out]
