"""Addendum 2 (prereg/ADDENDUM_2_HITCHITI.md): H1 and the Georgia-era check with Hitchiti.

Hitchiti forms: Gatschet (1884), A Migration Legend of the Creek Indians, vol. 1
(comparative table p. 56; Hitchiti sketch pp. 80-83; place-name gloss p. 71), in
cldf_addendum/hitchiti_forms.csv.

  A  H1 dating (criterion C6): for every Mikasuki residue concept that Gatschet's Hitchiti
     covers, is the Mikasuki form attested in Hitchiti? Cognate = SCA >= 0.55 (the frozen cut)
     or same LexStat/SCA cluster when Hitchiti joins the Stage 2 run.
  B  Hitchiti residue: Hitchiti items with no cognate in Choctaw, Chickasaw, Alabama, Koasati or
     Creek (Mikasuki, its sister, is excluded from this filter).
  C  Georgia-era check: Hitchiti (row) x Timucua (column), frozen two-way design, all shared
     concepts; and the Hitchiti residue if it has 5 or more concepts. Descriptive.
"""
import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd
from lingpy.compare.lexstat import LexStat

sys.path.insert(0, os.path.dirname(__file__))
from common import MUSKOGEAN, ROOT, load_cldf_forms, sim_sca  # noqa: E402
from twoway import get, summarize, twoway  # noqa: E402

spec = importlib.util.spec_from_file_location("grid", os.path.join(os.path.dirname(__file__), "05_similarity_grid.py"))
grid = importlib.util.module_from_spec(spec); spec.loader.exec_module(grid)
OUT = os.path.join(ROOT, "results", "h1_hitchiti")
os.makedirs(OUT, exist_ok=True)


def main():
    hi = pd.read_csv(os.path.join(ROOT, "cldf_addendum", "hitchiti_forms.csv"))
    hi["Parameter_ID"] = hi.Parameter_ID.astype(str)
    forms = load_cldf_forms(); forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    gloss = dict(zip(pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv")).ID.astype(str),
                     pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv")).Name))
    resid = json.load(open(os.path.join(ROOT, "results", "residue_concepts.json")))
    allf = grid.all_forms()
    allf["HITCHITI"] = {c: list(g.Segments) for c, g in hi.groupby("Parameter_ID")}

    # Stage 2 rerun with Hitchiti as a seventh list
    mus = forms[forms.Language_ID.isin(MUSKOGEAN)]
    D = {0: ["doculect", "concept", "ipa", "tokens", "src"]}; k = 1
    for r in mus.itertuples():
        D[k] = [r.Language_ID, r.Parameter_ID, r.Segments.replace(" ", ""), r.Segments.split(), r.ID]; k += 1
    for r in hi.itertuples():
        D[k] = ["HITCHITI", r.Parameter_ID, r.Segments.replace(" ", ""), r.Segments.split(), r.Gatschet_spelling]; k += 1
    lex = LexStat(D, check=True, segments="tokens")
    lex.get_scorer(runs=1000)
    lex.cluster(method="lexstat", threshold=0.55, cluster_method="infomap", ref="lexstatid")
    lex.cluster(method="sca", threshold=0.45, ref="scaid")
    cg = pd.DataFrame([dict(doculect=lex[i, "doculect"], concept=lex[i, "concept"], seg=" ".join(lex[i, "tokens"]),
                            lexstatid=lex[i, "lexstatid"], scaid=lex[i, "scaid"]) for i in lex])
    cg.to_csv(os.path.join(OUT, "stage2_with_hitchiti.csv"), index=False)

    def linked(row, others):
        return any(((cg[ref] == row[ref]) & cg.doculect.isin(others)).any() for ref in ("lexstatid", "scaid"))

    # ---------------------------------------------------------------- A. H1 dating
    rows = []
    for c in resid["MIKASUKI"]:
        if c not in allf["HITCHITI"]:
            rows.append(dict(concept=gloss[c], parameter_id=c, hitchiti_covered=False)); continue
        mf, hf = allf["MIKASUKI"][c], allf["HITCHITI"][c]
        best = max((sim_sca(a, b), a, b) for a in mf for b in hf)
        mrow = cg[(cg.doculect == "MIKASUKI") & (cg.concept == c)].iloc[0]
        rows.append(dict(concept=gloss[c], parameter_id=c, hitchiti_covered=True, mikasuki=best[1].replace(" ", ""),
                         hitchiti=best[2].replace(" ", ""), sca=round(best[0], 3),
                         clustered_with_hitchiti=linked(mrow, ["HITCHITI"]),
                         attested_in_hitchiti=bool(best[0] >= 0.55 or linked(mrow, ["HITCHITI"]))))
    h1 = pd.DataFrame(rows)
    h1.to_csv(os.path.join(OUT, "h1_mikasuki_residue_vs_hitchiti.csv"), index=False)
    cov = h1[h1.hitchiti_covered]
    n_abs = int((~cov.attested_in_hitchiti).sum())
    h1_verdict = "supported (checkable subset)" if len(cov) and n_abs > len(cov) / 2 else "not supported (checkable subset)"
    print(cov.to_string(), "\nH1:", h1_verdict, flush=True)

    # ---------------------------------------------------------------- B. Hitchiti residue
    hrows = []
    for r in cg[cg.doculect == "HITCHITI"].itertuples():
        inh = linked(pd.Series(r._asdict()), ["CHOCTAW", "CHICKASAW", "ALABAMA", "KOASATI", "CREEK"])
        hrows.append(dict(concept=gloss[r.concept], parameter_id=r.concept, form=r.seg.replace(" ", ""), inherited=inh))
    hr = pd.DataFrame(hrows)
    concept_inh = hr.groupby("parameter_id").inherited.any()
    hres = sorted([c for c, v in concept_inh.items() if not v], key=int)
    hr.to_csv(os.path.join(OUT, "hitchiti_residue.csv"), index=False)
    print("Hitchiti residue concepts:", [gloss[c] for c in hres], flush=True)

    # ---------------------------------------------------------------- C. Georgia-era check
    panel = list(pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID)
    for B in panel + ["TIMUCUA", "MIKASUKI"]:
        grid.pair_job(("HITCHITI", B, allf["HITCHITI"], allf[B]))
    langs = pd.read_csv(os.path.join(ROOT, "cldf", "languages.csv"))
    macro = dict(zip(langs.ID, langs.Macroarea)); macro["HITCHITI"] = "North America"
    T = allf["TIMUCUA"]
    out = dict(h1=dict(checkable=int(len(cov)), absent_from_hitchiti=n_abs, verdict=h1_verdict),
               hitchiti_residue=[gloss[c] for c in hres])
    keys = ["focal_n_items", "focal_dS", "focal_z", "focal_p_perm", "focal_p_row", "focal_p_col", "focal_p_max"]
    for label, C in [("all_shared", sorted([c for c in allf["HITCHITI"] if c in T], key=int)),
                     ("residue", [c for c in hres if c in T])]:
        if len(C) < 5:
            out[label] = f"skipped: {len(C)} concepts"; continue
        df = twoway("HITCHITI", "TIMUCUA", C, "SCA", panel, macro)
        df.to_csv(os.path.join(OUT, f"twoway_HITCHITI_x_TIMUCUA_{label}.csv"), index=False)
        s = summarize(df, "HITCHITI", "TIMUCUA")
        s["ruleset_A"] = bool(s["focal_p_perm"] < 0.05 and s["focal_p_max"] < 0.05)
        out[label] = {k: s[k] for k in keys + ["ruleset_A"]}
        print(label, out[label], flush=True)
    rows_, cols_, M = get("HITCHITI", "TIMUCUA", "SCA")
    cands = []
    for c in [c for c in rows_ if c in cols_]:
        i, j = rows_.index(c), cols_.index(c); obs = M[i, j]; oth = np.delete(M[i], j)
        best = max((sim_sca(a, b), a, b) for a in allf["HITCHITI"][c] for b in T[c])
        cands.append(dict(concept=gloss[c], hitchiti=best[1].replace(" ", ""), timucua=best[2].replace(" ", ""),
                          sim=round(obs, 3), rank=int((oth > obs).sum()) + 1,
                          p_candidate=round((1 + (oth >= obs).sum()) / (1 + len(oth)), 4), residue=c in hres))
    cd = pd.DataFrame(cands).sort_values("p_candidate")
    cd.to_csv(os.path.join(OUT, "hitchiti_candidates.csv"), index=False)
    out["candidates_p_le_05"] = cd[cd.p_candidate <= 0.05].concept.tolist()
    json.dump(out, open(os.path.join(OUT, "h1_summary.json"), "w"), indent=2,
              default=lambda x: x.item() if hasattr(x, "item") else str(x))
    print(cd.head(10).to_string())


if __name__ == "__main__":
    main()
