"""Precompute concept-by-concept similarity matrices (max over synonym pairs) for every
pair of languages in the analysis grid, for the three pre-registered measures.

Usage: python3 05_similarity_grid.py PHASE
  PHASE=pre   all grid languages EXCEPT Timucua (used for the placebo validation that
              fixed the decision rule before Timucua was compared with anything)
  PHASE=post  adds every pair involving Timucua (run only after the pre-registration
              hashes were written)
Writes results/grid/<A>__<B>.npz with matrices SCA, NED, TPG (rows = A concepts, cols = B concepts).
"""
import itertools
import os
import sys
from multiprocessing import Pool

import numpy as np
import pandas as pd
from rapidfuzz.distance import Levenshtein

from common import MUSKOGEAN, ROOT, concept_forms, dolgo, load_cldf_forms, turchin_key
from fastsca import sims as sca_sims

GRID = os.path.join(ROOT, "results", "grid")
FOCAL = ["MIKASUKI", "CREEK", "MUSK_INHERITED", "MOBILIAN_JARGON", "CHOCTAW", "YUCHI", "NATCHEZ", "WARAO",
         "KOASATI", "ALABAMA"]


def all_forms():
    forms = load_cldf_forms()
    forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    langs = sorted(forms.Language_ID.unique())
    allf = {L: concept_forms(forms, L) for L in langs}
    cog = pd.read_csv(os.path.join(ROOT, "results", "stage2_muskogean_cognates.csv"))
    cog["Parameter_ID"] = cog.Parameter_ID.astype(str)
    wide = cog.groupby("lexstatid").Language_ID.nunique()
    inh = {}
    for r in cog[cog.lexstatid.isin(set(wide[wide >= 3].index))].itertuples():
        inh.setdefault(r.Parameter_ID, set()).add(r.Segments)
    allf["MUSK_INHERITED"] = {c: sorted(v) for c, v in inh.items()}
    return allf


def pair_job(args):
    A, B, fa, fb = args
    out_path = os.path.join(GRID, f"{A}__{B}.npz")
    if os.path.exists(out_path):
        return A, B, "cached"
    ca, cb = sorted(fa, key=int), sorted(fb, key=int)
    pairs, index = [], []
    for i, c in enumerate(ca):
        for j, d in enumerate(cb):
            for a in fa[c]:
                for b in fb[d]:
                    pairs.append((a, b)); index.append((i, j))
    s = np.array(sca_sims(pairs))
    da = {a: dolgo(a) for c in ca for a in fa[c]}
    db = {b: dolgo(b) for d in cb for b in fb[d]}
    ned = np.array([1.0 - Levenshtein.normalized_distance(da[a], db[b]) if da[a] and db[b] else 0.0 for a, b in pairs])
    tpg = np.array([1.0 if turchin_key(a) == turchin_key(b) else 0.0 for a, b in pairs])
    mats = {}
    idx = np.array(index)
    for name, v in [("SCA", s), ("NED", ned), ("TPG", tpg)]:
        M = np.full((len(ca), len(cb)), -np.inf)
        np.maximum.at(M, (idx[:, 0], idx[:, 1]), v)
        mats[name] = M
    np.savez_compressed(out_path, rows=np.array(ca), cols=np.array(cb), **mats)
    return A, B, len(pairs)


def main(phase):
    os.makedirs(GRID, exist_ok=True)
    allf = all_forms()
    panel = list(pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID)
    langs = FOCAL + panel + (["TIMUCUA"] if phase == "post" else [])
    jobs = []
    for A, B in itertools.combinations(langs, 2):
        if phase == "post" and "TIMUCUA" not in (A, B):
            continue
        jobs.append((A, B, allf[A], allf[B]))
    print(phase, "language pairs:", len(jobs), flush=True)
    with Pool(2) as pool:
        for k, r in enumerate(pool.imap_unordered(pair_job, jobs, chunksize=4)):
            if k % 100 == 0:
                print(k, r, flush=True)
    print("done", flush=True)


if __name__ == "__main__":
    main(sys.argv[1])
