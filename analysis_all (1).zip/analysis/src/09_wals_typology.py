"""Exploratory (proposal section 10): does Timucua's grammatical resemblance to Warao or to
Muskogean exceed what random languages show? WALS feature-value overlap, percentile among
all WALS languages sharing at least 10 coded features with Timucua."""
import os
import pandas as pd
from common import EXT, ROOT

W = os.path.join(EXT, "wals", "cldf")
v = pd.read_csv(os.path.join(W, "values.csv"), low_memory=False)
langs = pd.read_csv(os.path.join(W, "languages.csv"), low_memory=False)
name = dict(zip(langs.ID, langs.Name)); macro = dict(zip(langs.ID, langs.Macroarea)); fam = dict(zip(langs.ID, langs.Family))
tab = v.pivot_table(index="Language_ID", columns="Parameter_ID", values="Value", aggfunc="first")
T = tab.loc["tmc"].dropna()
rows = []
for L in tab.index:
    if L == "tmc":
        continue
    o = tab.loc[L, T.index].dropna()
    if len(o) < 10:
        continue
    rows.append(dict(wals_code=L, language=name.get(L), family=fam.get(L), macroarea=macro.get(L),
                     shared_features=len(o), agreement=float((o == T[o.index]).mean())))
df = pd.DataFrame(rows)
df["percentile"] = df.agreement.rank(pct=True)
focus = df[df.wals_code.isin(["wra", "crk", "cct", "cck", "abm", "koa", "mki"])]
out = os.path.join(ROOT, "results", "wals_typology.csv")
df.sort_values("agreement", ascending=False).to_csv(out, index=False)
print("Timucua coded features:", len(T), "| comparison languages:", len(df))
print(focus[["language", "family", "shared_features", "agreement", "percentile"]].round(3).to_string())
print(df.sort_values("agreement", ascending=False).head(8)[["language", "family", "macroarea", "shared_features", "agreement"]].round(3).to_string())
