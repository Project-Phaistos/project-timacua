"""Two-way (recipient x donor) control design for the aggregate contact test.

For every cell (row language i standing in for the recipient, column language j standing
in for the donor) we compute, over the focal concept set C:
  S_obs  mean same-concept similarity
  dS     S_obs - E[S_perm]   (E is exact: the mean of all row-item x donor-concept entries)
  z      dS / SD[S_perm]     (SD from permutations of donor concept labels)
  p_perm one-sided permutation p
Then an additive model z_ij = mu + r_i + c_j + e_ij is fitted (cells pairing two languages
from the same macroarea are excluded as possible areal contact; the diagonal is excluded).
The contact statistic for the focal cell is its leave-cell-out interaction residual e,
compared with the leave-cell-out residuals of all reference cells.
"""
import os

import numpy as np
import pandas as pd

from common import ROOT, SEED

GRID = os.path.join(ROOT, "results", "grid")
_cache = {}


def load_strata():
    st = pd.read_csv(os.path.join(ROOT, "cldf", "concept_strata.csv"))
    return dict(zip(st.ID.astype(str), st.stratum))


def get(A, B, measure):
    key = (A, B, measure)
    if key in _cache:
        return _cache[key]
    p1, p2 = os.path.join(GRID, f"{A}__{B}.npz"), os.path.join(GRID, f"{B}__{A}.npz")
    if os.path.exists(p1):
        z = np.load(p1)
        out = (list(z["rows"]), list(z["cols"]), z[measure])
    elif os.path.exists(p2):
        z = np.load(p2)
        out = (list(z["cols"]), list(z["rows"]), z[measure].T)
    else:
        raise FileNotFoundError(f"{A}/{B}")
    _cache[key] = out
    return out


def cell_stats(i, j, C, measure, n_perm, rng, min_items, strata=None):
    """strata: optional dict concept -> stratum; permutations then stay within strata."""
    rows, cols, M = get(i, j, measure)
    items = [c for c in C if c in rows and c in cols]
    if len(items) < min_items:
        return None
    ri = np.array([rows.index(c) for c in items]); ti = np.array([cols.index(c) for c in items])
    Mx = M[ri]
    k, n = Mx.shape
    s_obs = Mx[np.arange(k), ti].mean()
    if strata is None:
        mu = Mx.mean()
        perms = np.argsort(rng.random((n_perm, n)), axis=1)[:, :k]
        null = Mx[np.arange(k)[None, :], perms].mean(axis=1)
    else:
        null = np.zeros(n_perm); mu_parts = []
        for s in sorted({strata[c] for c in items}):
            ii = np.array([a for a, c in enumerate(items) if strata[c] == s])
            jj = np.array([b for b, d in enumerate(cols) if strata.get(d) == s])
            sub = Mx[np.ix_(ii, jj)]
            ks, ns = sub.shape
            mu_parts.append(sub.mean(axis=1))
            if ks <= ns:
                pr = np.argsort(rng.random((n_perm, ns)), axis=1)[:, :ks]
            else:
                pr = rng.integers(0, ns, size=(n_perm, ks))
            null += sub[np.arange(ks)[None, :], pr].sum(axis=1)
        null /= k
        mu = np.concatenate(mu_parts).mean()
    sd = null.std(ddof=1)
    return dict(row=i, col=j, n_items=k, S_obs=s_obs, null_mean=mu, dS=s_obs - mu,
                z=(s_obs - mu) / sd if sd > 0 else 0.0, p_perm=(1 + (null >= s_obs).sum()) / (1 + n_perm))


def additive_fit(Z, W, iters=60):
    """Weighted additive fit on matrix Z with 0/1 weights W (1 = used). Returns mu, r, c."""
    mu = np.nansum(Z * W) / W.sum()
    r = np.zeros(Z.shape[0]); c = np.zeros(Z.shape[1])
    Zf = np.nan_to_num(Z)
    for _ in range(iters):
        rw = W.sum(1); r = np.where(rw > 0, ((Zf - mu - c[None, :]) * W).sum(1) / np.maximum(rw, 1), 0)
        cw = W.sum(0); c = np.where(cw > 0, ((Zf - mu - r[:, None]) * W).sum(0) / np.maximum(cw, 1), 0)
        mu = ((Zf - r[:, None] - c[None, :]) * W).sum() / W.sum()
    return mu, r, c


def twoway(focal_row, focal_col, C, measure, panel, macro, n_perm_ref=2000, n_perm_focal=10_000,
           min_frac=0.6, seed=SEED, strata=None):
    """focal_col may be None (placebo mode: columns = panel only)."""
    rows = [focal_row] + [p for p in panel if p != focal_row]
    cols = ([focal_col] if focal_col else []) + [p for p in panel if p not in (focal_row, focal_col)]
    base_items = [c for c in C]
    if focal_col:
        r0, c0, _ = get(focal_row, focal_col, measure)
        base_items = [c for c in C if c in r0 and c in c0]
    min_items = max(3, int(np.ceil(min_frac * len(base_items))))
    rng = np.random.default_rng(seed)
    recs = []
    for i in rows:
        for j in cols:
            if i == j:
                continue
            focal = (i == focal_row and j == focal_col)
            s = cell_stats(i, j, base_items, measure, n_perm_focal if focal else n_perm_ref, rng, min_items, strata)
            if s:
                s["focal"] = focal
                s["same_macroarea"] = macro.get(i) == macro.get(j)
                recs.append(s)
    df = pd.DataFrame(recs)
    ri = {L: k for k, L in enumerate(rows)}; ci = {L: k for k, L in enumerate(cols)}
    Z = np.full((len(rows), len(cols)), np.nan)
    for r in df.itertuples():
        Z[ri[r.row], ci[r.col]] = r.z
    use = ~np.isnan(Z)
    ref_mask = np.zeros_like(use)
    for r in df.itertuples():
        if not r.focal and not r.same_macroarea:
            ref_mask[ri[r.row], ci[r.col]] = True
    W = ref_mask.astype(float)
    # leave-cell-out residuals for every cell with data (focal is never in W)
    resid = np.full(len(df), np.nan)
    for k, r in enumerate(df.itertuples()):
        a, b = ri[r.row], ci[r.col]
        Wk = W.copy(); Wk[a, b] = 0
        mu, rr, cc = additive_fit(Z, Wk, iters=25)
        resid[k] = r.z - (mu + rr[a] + cc[b])
    df["interaction"] = resid
    ref = df[(~df.focal) & (~df.same_macroarea)]
    df["p_twoway"] = [(1 + (ref.interaction.drop(index=k, errors="ignore") >= e).sum()) / (1 + len(ref) - (0 if f else 1))
                      for k, e, f in zip(df.index, df.interaction, df.focal)]
    return rank_pvalues(df)


def summarize(df, focal_row, focal_col):
    ref = df[(~df.focal) & (~df.same_macroarea)]
    flag = (ref.p_max < 0.05) & (ref.p_perm < 0.05)
    out = dict(reference_cells=len(ref), fpr_new_rule_all_cells=float(flag.mean()),
               fpr_pooled_twoway_all_cells=float(((ref.p_twoway < 0.05) & (ref.p_perm < 0.05)).mean()),
               perm_only_fpr_all_cells=float((ref.p_perm < 0.05).mean()))
    rowcells = ref[ref.row == focal_row]
    out["fpr_new_rule_focal_row"] = float(((rowcells.p_max < 0.05) & (rowcells.p_perm < 0.05)).mean()) if len(rowcells) else np.nan
    if focal_col is not None:
        colcells = ref[ref.col == focal_col]
        out["fpr_new_rule_focal_col"] = float(((colcells.p_max < 0.05) & (colcells.p_perm < 0.05)).mean()) if len(colcells) else np.nan
    out["perm_only_fpr_focal_row"] = float((rowcells.p_perm < 0.05).mean()) if len(rowcells) else np.nan
    # the ORIGINAL rule (a)+(b)+(c), evaluated on the focal row's placebo donors
    old = []
    for j, g in df[(~df.same_macroarea) | (df.focal)].groupby("col"):
        fr = g[g.row == focal_row]
        if not len(fr):
            continue
        others = g[g.row != focal_row]
        prim = others.iloc[0] if len(others) else None
        q95 = others.dS.quantile(0.95)
        d = fr.iloc[0]
        old.append((j, d.p_perm < 0.05 and prim is not None and d.dS > prim.dS and d.dS > q95))
    oldf = pd.DataFrame(old, columns=["col", "flag"])
    if focal_col:
        oldf = oldf[oldf.col != focal_col]
    out["fpr_original_rule_focal_row"] = float(oldf.flag.mean()) if len(oldf) else np.nan
    if focal_col is not None and df.focal.any():
        f = df[df.focal].iloc[0]
        col = df[(df.col == focal_col) & (~df.focal)]
        row = df[(df.row == focal_row) & (~df.focal) & (~df.same_macroarea)]
        out.update(focal_n_items=int(f.n_items), focal_S=f.S_obs, focal_dS=f.dS, focal_z=f.z, focal_p_perm=f.p_perm,
                   focal_interaction=f.interaction, focal_p_twoway=f.p_twoway, focal_p_row=f.p_row,
                   focal_p_col=f.p_col, focal_p_max=f.p_max,
                   recipient_panel_pct=float((col.dS < f.dS).mean()), recipient_panel_q95_dS=float(col.dS.quantile(0.95)),
                   donor_panel_pct=float((row.dS < f.dS).mean()),
                   primary_control_dS=float(col[col.row == col.row.iloc[0]].dS.iloc[0]) if len(col) else np.nan)
    return out


def rank_pvalues(df):
    """Row/column rank p-values for each cell's leave-cell-out interaction residual.
    p_row: rank among the same row's other reference cells (other stand-in donors);
    p_col: rank among the same column's other reference cells (other stand-in recipients);
    p_max = max(p_row, p_col). Reference cells exclude the diagonal, same-macroarea pairs and
    the focal cell. Robust to row- or column-specific variance (heteroscedasticity)."""
    df = df.copy()
    ref = ((~df.focal) & (~df.same_macroarea)).values
    e = df.interaction.values
    for key, out in (("row", "p_row"), ("col", "p_col")):
        p = np.empty(len(df))
        for _, idx in df.groupby(key).indices.items():
            idx = np.asarray(idx)
            refvals = e[idx][ref[idx]]
            for k in idx:
                cnt = (refvals >= e[k]).sum() - (1 if ref[k] else 0)
                n = len(refvals) - (1 if ref[k] else 0)
                p[k] = (1 + cnt) / (1 + n)
        df[out] = p
    df["p_max"] = np.maximum(df.p_row, df.p_col)
    return df
