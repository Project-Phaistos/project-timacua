"""Shared helpers for the Recovering Timucua pilot.

Similarity measures (pre-registered, see prereg/PREREGISTRATION.md):
  primary   SCA   1 - normalized SCA alignment distance (List 2012; LingPy Pairwise, model='sca', global mode)
  secondary NED   1 - normalized edit distance over Dolgopolsky sound classes
  tertiary  TPG   binary match of the first two consonant classes (Turchin, Peiros & Gell-Mann 2010)
"""
from __future__ import annotations

import functools
import logging
import os
import re

logging.getLogger("lingpy").setLevel(logging.ERROR)
logging.disable(logging.INFO)

import numpy as np
import pandas as pd
from lingpy.align.pairwise import Pairwise
from lingpy.sequence.sound_classes import tokens2class

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXT = os.environ.get(
    "TIMUCUA_EXT",
    "/tmp/claude-0/-home-claude/b5ae2517-b589-579e-913a-ccba6dd0f3f0/scratchpad/ext",
)
SEED = 20261010  # pre-registered RNG seed
N_PERM = 10_000

MUSKOGEAN = ["MIKASUKI", "CREEK", "CHOCTAW", "CHICKASAW", "ALABAMA", "KOASATI"]
RECIPIENTS = ["MIKASUKI", "CREEK"]
DONOR = "TIMUCUA"


# ---------------------------------------------------------------- normalization
def normalize_segments(segs: str, language_family: str | None = None, language: str | None = None) -> list[str]:
    """Normalize ASJP-derived segment strings. Every rule here is logged in
    cldf/normalization_log.csv by 01_build_dataset.py."""
    toks = [t for t in str(segs).split() if t not in ("", "+", "_", "#")]
    out = []
    for t in toks:
        # R1: ASJP 'a' is rendered as ɐ by the lexibank profile; SCA would class it with e.
        t = t.replace("ɐ", "a")
        # R2: in Muskogean sources ASJP 'L' stands for the voiceless lateral fricative.
        if language_family == "Muskogean":
            t = t.replace("ʎ", "ɬ")
        out.append(t)
    # R4: Creek verbs are cited in the infinitive with suffix -itá (Martin 2011); the
    # suffix is stripped so that stems, not citation morphology, are compared.
    if language == "CREEK" and len(out) >= 5 and out[-3:] == ["i", "t", "a"]:
        out = out[:-3]
    return out


def cv_profile(tokens: list[str]) -> str:
    return "".join(tokens2class(tokens, "cv"))


# ---------------------------------------------------------------- similarity
@functools.lru_cache(maxsize=None)
def sim_sca(a: str, b: str) -> float:
    """a, b: space-separated segment strings."""
    p = Pairwise(a, b)
    p.align(distance=True, model="sca", mode="global")
    return 1.0 - p.alignments[0][2]


@functools.lru_cache(maxsize=None)
def dolgo(a: str) -> str:
    return "".join(tokens2class(a.split(), "dolgo"))


def _lev(s: str, t: str) -> int:
    prev = list(range(len(t) + 1))
    for i, cs in enumerate(s, 1):
        cur = [i]
        for j, ct in enumerate(t, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (cs != ct)))
        prev = cur
    return prev[-1]


@functools.lru_cache(maxsize=None)
def sim_ned(a: str, b: str) -> float:
    da, db = dolgo(a), dolgo(b)
    if not da or not db:
        return 0.0
    return 1.0 - _lev(da, db) / max(len(da), len(db))


@functools.lru_cache(maxsize=None)
def turchin_key(a: str) -> str:
    """First two consonant classes (Dolgopolsky), vowels skipped.
    Following Turchin et al. (2010), a word with only one consonant is keyed on
    that consonant plus a placeholder."""
    cls = [c for c in dolgo(a) if c not in ("V", "1", "2", "3", "4", "5", "_", "+")]
    cls = [c for c in cls if c != "0"]
    if not cls:
        return "--"
    if len(cls) == 1:
        return cls[0] + "-"
    return cls[0] + cls[1]


@functools.lru_cache(maxsize=None)
def sim_tpg(a: str, b: str) -> float:
    return 1.0 if turchin_key(a) == turchin_key(b) else 0.0


SIMS = {"SCA": sim_sca, "NED": sim_ned, "TPG": sim_tpg}


# ---------------------------------------------------------------- data access
def load_cldf_forms() -> pd.DataFrame:
    f = pd.read_csv(os.path.join(ROOT, "cldf", "forms.csv"))
    f["Segments"] = f["Segments"].astype(str)
    return f


def concept_forms(forms: pd.DataFrame, lang: str) -> dict[str, list[str]]:
    sub = forms[forms.Language_ID == lang]
    return {c: list(g.Segments) for c, g in sub.groupby("Parameter_ID")}


def concept_matrix(xa: dict, ya: dict, measure: str = "SCA"):
    """M[i, j] = max similarity between forms of concept xi (language X) and concept yj (language Y)."""
    f = SIMS[measure]
    xc, yc = sorted(xa), sorted(ya)
    M = np.zeros((len(xc), len(yc)))
    for i, c in enumerate(xc):
        for j, d in enumerate(yc):
            M[i, j] = max(f(a, b) for a in xa[c] for b in ya[d])
    return xc, yc, M


def perm_test(M, xc, yc, concepts, n_perm=N_PERM, seed=SEED):
    """Aggregate statistic S = mean over concepts c of M[c, c]; null permutes the
    concept labels of Y (sampled without replacement from all Y concepts).
    Returns S_obs, null array, one-sided p with +1 correction."""
    rng = np.random.default_rng(seed)
    xi = np.array([xc.index(c) for c in concepts])
    yi = np.array([yc.index(c) for c in concepts])
    s_obs = M[xi, yi].mean()
    ny = len(yc)
    null = np.empty(n_perm)
    for k in range(n_perm):
        perm = rng.choice(ny, size=len(concepts), replace=False)
        null[k] = M[xi, perm].mean()
    p = (1 + (null >= s_obs).sum()) / (1 + n_perm)
    return s_obs, null, p


def candidate_p(M, xc, yc, c):
    """Exact per-item permutation p: rank of the true-concept match among matches
    of the same X item against every other Y concept."""
    i, j = xc.index(c), yc.index(c)
    obs = M[i, j]
    others = np.delete(M[i], j)
    return obs, (1 + (others >= obs).sum()) / (1 + len(others))


def bh(pvals, q=0.05):
    """Benjamini-Hochberg. Returns boolean rejections and adjusted p-values."""
    p = np.asarray(pvals, dtype=float)
    m = len(p)
    if m == 0:
        return np.array([], bool), np.array([])
    order = np.argsort(p)
    ranked = p[order] * m / (np.arange(m) + 1)
    adj = np.minimum.accumulate(ranked[::-1])[::-1]
    adj = np.minimum(adj, 1.0)
    out = np.empty(m)
    out[order] = adj
    return out <= q, out
