"""Month 3 validation: run the Stage 3-5 machinery on a KNOWN contact case.

Known case: Spanish loans in nine WOLD languages of the Americas and North Africa,
with gold-standard loan labels from WOLD (Haspelmath & Tadmor 2009). Donor lexicon:
IDS Spanish (Key & Comrie), converted to Latin-American Spanish phonology.

Outputs (validation/):
  wold_aggregate.csv      aggregate permutation test per language, full list and ASJP-100 subset
  wold_candidates.csv     per-concept p-values, BH decisions, gold labels
  wold_candidate_metrics.csv  precision / recall / AUC per language
  stage3_filter_eval.csv  how well the Stage 3 European-loan cut (SCA sim >= 0.55) separates loans
  power_grid.csv          planted-real-loan power analysis (aggregate and candidate level)
No Timucua data are used.
"""
import json
import os
import re
import sys
import unicodedata
from multiprocessing import Pool

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
from common import EXT, ROOT, SEED, bh, sim_sca  # noqa: E402

OUT = os.path.join(ROOT, "validation")
LANGS = ["Yaqui", "ImbaburaQuechua", "Mapudungun", "Otomi", "ZinacantanTzotzil", "Qeqchi", "Wichi"]
CAP = 450
EURO_CUT = 0.55


# ----------------------------------------------------------- Spanish orthography -> segments
def es2seg(word: str) -> list[str]:
    w = word.lower().strip().split()[0] if word.strip() else ""
    w = w.replace("ü", "W")
    w = "".join(c for c in unicodedata.normalize("NFD", w) if unicodedata.category(c) != "Mn")
    w = w.replace("ñ", "ɲ")
    # placeholders (upper case) protect outputs from later rules
    rules = [("ch", "C"), ("ll", "Y"), ("rr", "R"), ("qu", "K"), ("gW", "Gw"),
             (r"gu(?=[ei])", "G"), (r"g(?=[ei])", "X"), (r"c(?=[ei])", "s"), ("c", "K"),
             ("z", "s"), ("j", "X"), ("x", "ks"), ("h", ""), ("v", "b"), (r"y$", "i"), ("y", "Y")]
    for a, b in rules:
        w = re.sub(a, b, w)
    w = w.replace("K", "k").replace("G", "g").replace("X", "x").replace("Y", "j")
    segs = []
    for ch in w:
        if ch == "C":
            segs.append("tʃ")
        elif ch == "R":
            segs.append("r")
        elif ch.isalpha() or ch == "ɲ":
            segs.append(ch)
    return segs


def load():
    wf = pd.read_csv(os.path.join(EXT, "wold", "cldf", "forms.csv"), low_memory=False)
    wb = pd.read_csv(os.path.join(EXT, "wold", "cldf", "borrowings.csv"), low_memory=False)
    wp = pd.read_csv(os.path.join(EXT, "wold", "cldf", "parameters.csv"))
    sp_from = set(wb[wb.Source_languoid.fillna("").str.contains("Spanish")].Target_Form_ID)
    wf = wf[wf.Language_ID.isin(LANGS)].copy()
    wf["cid"] = wf.Parameter_ID.map(dict(zip(wp.ID, wp.Concepticon_ID)))
    wf = wf[wf.cid.notna()]
    wf["seg"] = wf.Segments.astype(str).str.replace(r"\s*\+\s*", " ", regex=True).str.replace("_", " ").str.split().str.join(" ")
    wf = wf[wf.seg.str.len() > 0]
    wf["es_loan"] = wf.ID.isin(sp_from) & wf.Borrowed.isin(["1. clearly borrowed", "2. probably borrowed"])
    wf["native"] = wf.Borrowed.eq("5. no evidence for borrowing")

    idsf = pd.read_csv(os.path.join(EXT, "ids", "cldf", "forms.csv"), low_memory=False)
    idsp = pd.read_csv(os.path.join(EXT, "ids", "cldf", "parameters.csv"))
    es = idsf[idsf.Language_ID.astype(str) == "176"].copy()
    es["cid"] = es.Parameter_ID.map(dict(zip(idsp.ID, idsp.Concepticon_ID)))
    es = es[es.cid.notna()]
    es["seg"] = es.Form.astype(str).map(lambda x: " ".join(es2seg(x)))
    es = es[es.seg.str.split().str.len() >= 2]
    asjp_c = set(pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv")).Concepticon_ID.dropna().astype(int))
    return wf, es, asjp_c


def build_lang(args):
    L, wf, es, seed = args
    rng = np.random.default_rng(seed)
    w = wf[wf.Language_ID == L]
    esd = {c: list(g.seg) for c, g in es.groupby("cid")}
    concepts = sorted(set(w.cid) & set(esd))
    loan_c = sorted({c for c in concepts if w[(w.cid == c) & w.es_loan].shape[0]})
    nat_c = sorted({c for c in concepts if w[(w.cid == c) & w.native].shape[0]})
    if len(concepts) > CAP:  # keep every loan concept, fill with random others
        rest = [c for c in concepts if c not in set(loan_c)]
        keep = set(loan_c) | set(rng.choice(rest, size=max(0, CAP - len(loan_c)), replace=False))
        concepts = sorted(keep)
    loan_c = [c for c in loan_c if c in concepts]
    nat_c = [c for c in nat_c if c in concepts]
    idx = {c: i for i, c in enumerate(concepts)}
    n = len(concepts)
    M_all = np.zeros((n, n)); M_loan = np.full((n, n), np.nan); M_nat = np.full((n, n), np.nan)
    forms = {c: w[w.cid == c] for c in concepts}
    for c in concepts:
        f = forms[c]
        allf, lf, nf = list(f.seg), list(f[f.es_loan].seg), list(f[f.native].seg)
        for d in concepts:
            sims = {a: max(sim_sca(a, b) for b in esd[d]) for a in allf}
            M_all[idx[c], idx[d]] = max(sims.values())
            if lf:
                M_loan[idx[c], idx[d]] = max(sims[a] for a in lf)
            if nf:
                M_nat[idx[c], idx[d]] = max(sims[a] for a in nf)
    gold = {c: bool(forms[c].es_loan.any()) for c in concepts}
    # stage 3 filter evaluation: best same-concept Spanish similarity per form
    s3 = []
    for c in concepts:
        for r in forms[c].itertuples():
            s3.append(dict(language=L, cid=c, form=r.Form, es_loan=r.es_loan, native=r.native,
                           best_same_concept_sim=max(sim_sca(r.seg, b) for b in esd[c])))
    return L, dict(concepts=concepts, M_all=M_all, M_loan=M_loan, M_nat=M_nat, gold=gold,
                   loan_c=loan_c, nat_c=nat_c), s3


def perm_p(M, rows, cols_true, ncols_pool, rng, n_perm):
    s_obs = M[rows, cols_true].mean()
    cnt = 0
    for _ in range(n_perm):
        perm = rng.choice(ncols_pool, size=len(rows), replace=False)
        cnt += M[rows, perm].mean() >= s_obs
    return s_obs, (1 + cnt) / (1 + n_perm)


def main():
    os.makedirs(OUT, exist_ok=True)
    wf, es, asjp_c = load()
    print("Spanish IDS forms:", len(es), "WOLD forms:", len(wf))
    jobs = [(L, wf, es, SEED + i) for i, L in enumerate(LANGS)]
    with Pool(2) as pool:
        res = pool.map(build_lang, jobs)
    data = {L: d for L, d, _ in res}
    s3 = pd.DataFrame([r for _, _, rows in res for r in rows])
    np.savez_compressed(os.path.join(OUT, "wold_matrices.npz"),
                        **{f"{L}__{k}": v for L, d in data.items() for k, v in d.items() if k.startswith("M_")})
    json.dump({L: dict(concepts=[int(c) for c in d["concepts"]], loan_c=[int(c) for c in d["loan_c"]],
                       nat_c=[int(c) for c in d["nat_c"]]) for L, d in data.items()},
              open(os.path.join(OUT, "wold_concepts.json"), "w"))

    rng = np.random.default_rng(SEED)
    agg, cands, metrics = [], [], []
    for L, d in data.items():
        cs = d["concepts"]; M = d["M_all"]; n = len(cs)
        for subset_name, sub in [("full", cs), ("asjp100", [c for c in cs if int(c) in asjp_c])]:
            ii = np.array([cs.index(c) for c in sub])
            if subset_name == "full":
                s_obs, p = perm_p(M, ii, ii, n, rng, 10_000)
                pool_cols = np.arange(n)
            else:
                Msub = M[np.ix_(ii, ii)]
                s_obs, p = perm_p(Msub, np.arange(len(ii)), np.arange(len(ii)), len(ii), rng, 10_000)
            nloan = sum(d["gold"][c] for c in sub)
            agg.append(dict(language=L, list=subset_name, n_concepts=len(sub), n_loan_concepts=nloan,
                            loan_share=round(nloan / len(sub), 3), S_obs=round(s_obs, 4), p_perm=p))
            # candidate level: each concept vs every other donor concept in the same list
            Mx = M[np.ix_(ii, ii)]
            obs = np.diag(Mx)
            pc = np.array([(1 + (np.delete(Mx[k], k) >= obs[k]).sum()) / len(sub) for k in range(len(sub))])
            rej, padj = bh(pc, 0.05)
            g = np.array([d["gold"][c] for c in sub])
            tp = int((rej & g).sum()); fp = int((rej & ~g).sum())
            from scipy.stats import mannwhitneyu
            auc = (mannwhitneyu(obs[g], obs[~g]).statistic / (g.sum() * (~g).sum())) if g.any() and (~g).any() else np.nan
            metrics.append(dict(language=L, list=subset_name, n=len(sub), gold_loans=int(g.sum()),
                                min_possible_p=round(1 / len(sub), 4), bh_rejections=int(rej.sum()), TP=tp, FP=fp,
                                precision=round(tp / max(1, tp + fp), 3), recall=round(tp / max(1, g.sum()), 3),
                                auc_sim=round(auc, 3)))
            if subset_name == "full":
                for k, c in enumerate(sub):
                    cands.append(dict(language=L, cid=int(c), sim=round(obs[k], 3), p=pc[k], p_bh=padj[k],
                                      bh_reject=bool(rej[k]), gold_spanish_loan=bool(g[k])))
    pd.DataFrame(agg).to_csv(os.path.join(OUT, "wold_aggregate.csv"), index=False)
    pd.DataFrame(cands).to_csv(os.path.join(OUT, "wold_candidates.csv"), index=False)
    pd.DataFrame(metrics).to_csv(os.path.join(OUT, "wold_candidate_metrics.csv"), index=False)

    # Stage 3 filter evaluation
    s3["flag"] = s3.best_same_concept_sim >= EURO_CUT
    s3e = []
    for L, g in list(s3.groupby("language")) + [("ALL", s3)]:
        s3e.append(dict(language=L, loans=int(g.es_loan.sum()), natives=int(g.native.sum()),
                        recall_on_loans=round(g[g.es_loan].flag.mean(), 3),
                        false_flag_rate_on_natives=round(g[g.native].flag.mean(), 3)))
    pd.DataFrame(s3e).to_csv(os.path.join(OUT, "stage3_filter_eval.csv"), index=False)
    print(pd.DataFrame(agg).to_string()); print(pd.DataFrame(metrics).to_string()); print(pd.DataFrame(s3e).to_string())

    # ------------------------------------------------ power grid with planted real loans
    resid_frac = 0.21  # Mikasuki residue share in the pilot (20/95 concepts)
    grid = []
    reps, n_perm = 300, 999
    for Ncl in [100, 200, 350]:
        n_res = max(5, int(round(resid_frac * Ncl)))
        for k in [0, 1, 2, 3, 4, 6, 8, 12, 16, 24]:
            if k > n_res:
                continue
            hits = cand_hits = cand_fp = 0
            for rep in range(reps):
                L = LANGS[rng.integers(len(LANGS))]
                d = data[L]; cs = d["concepts"]
                loan_pool = [c for c in d["loan_c"]]
                nat_pool = [c for c in d["nat_c"] if c not in set(d["loan_c"])]
                if len(loan_pool) < k or len(nat_pool) < n_res - k or len(cs) < Ncl:
                    continue
                lc = list(rng.choice(loan_pool, size=k, replace=False)) if k else []
                nc = list(rng.choice(nat_pool, size=n_res - k, replace=False))
                resid = lc + nc
                others = [c for c in cs if c not in set(resid)]
                donor = resid + list(rng.choice(others, size=Ncl - n_res, replace=False))
                ri = [cs.index(c) for c in resid]; di = np.array([cs.index(c) for c in donor])
                Mr = np.vstack([d["M_loan"][cs.index(c)] if c in lc else d["M_nat"][cs.index(c)] for c in resid])[:, di]
                obs = np.diag(Mr[:, :n_res])
                s_obs = obs.mean()
                null = np.array([Mr[np.arange(n_res), rng.choice(Ncl, n_res, replace=False)].mean() for _ in range(n_perm)])
                p = (1 + (null >= s_obs).sum()) / (1 + n_perm)
                hits += p < 0.05
                pc = np.array([(1 + (np.delete(Mr[j], j) >= obs[j]).sum()) / Ncl for j in range(n_res)])
                rej, _ = bh(pc, 0.05)
                cand_hits += rej[:k].any() if k else 0
                cand_fp += rej[k:].sum()
            grid.append(dict(concept_list=Ncl, residue_items=n_res, planted_loans=k, reps=reps,
                             power_aggregate=round(hits / reps, 3),
                             p_any_true_loan_survives_BH=round(cand_hits / reps, 3) if k else np.nan,
                             mean_false_candidates_per_run=round(cand_fp / reps, 3)))
            print(grid[-1], flush=True)
    pd.DataFrame(grid).to_csv(os.path.join(OUT, "power_grid.csv"), index=False)


if __name__ == "__main__":
    main()
