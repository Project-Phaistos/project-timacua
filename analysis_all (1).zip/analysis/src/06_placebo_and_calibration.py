"""Pre-freeze validation of the decision rule (no Timucua comparisons).

1. Placebo: Mikasuki and Creek residue concept sets (restricted to concepts Timucua
   attests, which uses Timucua's concept coverage only), with the 50 panel languages as
   stand-in donors. Every reference cell is treated in turn as if it were the focal test,
   which gives the false-positive rate of (i) the permutation test alone, (ii) the original
   rule (a)+(b)+(c), and (iii) the two-way rule (a)+(c*).
2. Calibration on known relationships and contact, two-way design:
   Mobilian Jargon x Choctaw (pidgin and its lexifier), Mikasuki x Creek and Koasati x Alabama
   (related), Yuchi x Creek and Natchez x Creek (historical contact, 40-item lists).
"""
import json
import os

import pandas as pd

from common import ROOT, concept_forms, load_cldf_forms
from twoway import summarize, twoway

OUT = os.path.join(ROOT, "validation")


def main():
    langs = pd.read_csv(os.path.join(ROOT, "cldf", "languages.csv"))
    macro = dict(zip(langs.ID, langs.Macroarea)); macro["MUSK_INHERITED"] = "North America"
    panel = list(pd.read_csv(os.path.join(ROOT, "cldf", "control_panel.csv")).ID)
    forms = load_cldf_forms(); forms["Parameter_ID"] = forms.Parameter_ID.astype(str)
    t_concepts = set(forms[forms.Language_ID == "TIMUCUA"].Parameter_ID)  # coverage only
    resid = json.load(open(os.path.join(ROOT, "results", "residue_concepts.json")))
    rows = []
    for L in ["MIKASUKI", "CREEK"]:
        C = [c for c in resid[L] if c in t_concepts]
        for measure in ["SCA", "NED", "TPG"]:
            df = twoway(L, None, C, measure, panel, macro)
            s = summarize(df, L, None)
            s.update(analysis=f"placebo: {L} residue x panel donors", measure=measure, n_concepts=len(C))
            rows.append(s); print(s, flush=True)
            df.to_csv(os.path.join(OUT, f"placebo_{L}_{measure}.csv"), index=False)
    for a, b in [("MOBILIAN_JARGON", "CHOCTAW"), ("MIKASUKI", "CREEK"), ("KOASATI", "ALABAMA"),
                 ("YUCHI", "CREEK"), ("NATCHEZ", "CREEK")]:
        fa = set(forms[forms.Language_ID == a].Parameter_ID); fb = set(forms[forms.Language_ID == b].Parameter_ID)
        C = sorted(fa & fb, key=int)
        df = twoway(a, b, C, "SCA", panel, macro)
        s = summarize(df, a, b)
        s.update(analysis=f"calibration: {a} x {b}", measure="SCA", n_concepts=len(C))
        rows.append(s); print(s, flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "placebo_and_calibration.csv"), index=False)


if __name__ == "__main__":
    main()
