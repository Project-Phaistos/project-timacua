"""Assemble the planned concept lists (paper section 4):
  basic     Swadesh (1952) 200-item list, via Concepticon
  extended  ~150 Florida ecology / subsistence / material-culture / social concepts
  european  30-item validation block of post-contact items (expected Spanish/English loans)
Each concept is linked to Concepticon and, where WOLD has the meaning, to its
cross-linguistic Borrowed_score (Haspelmath & Tadmor 2009) as a prior on borrowability.
"""
import os
import pandas as pd
from common import EXT, ROOT

CC = os.path.join(EXT, "concepticon-data", "concepticondata")
EXT_LIST = {
 "Fauna": ["ALLIGATOR", "CROCODILE", "TURTLE", "TORTOISE", "DEER", "BEAR", "OPOSSUM", "RACCOON", "RABBIT", "SQUIRREL",
           "TURKEY", "HERON", "CRANE", "VULTURE", "OWL", "EAGLE", "HAWK", "SNAKE", "RATTLESNAKE", "FROG", "CATFISH",
           "SHARK", "FISHING SPEAR", "CRAB", "MOSQUITO", "PUMA", "WOLF", "FOX", "BISON", "BEAVER", "OTTER", "SKUNK",
           "BAT", "DUCK", "GOOSE", "PARROT", "WOODPECKER", "LIZARD", "SNAIL", "SPIDER", "BEE", "BUTTERFLY", "FLY (INSECT)",
           "WORM", "DOVE", "QUAIL", "JAGUAR", "WILD CAT"],
 "Flora": ["OAK", "PINE", "CEDAR", "CYPRESS", "PALM TREE", "REED", "BAMBOO", "MOSS", "WALNUT", "ACORN",
           "GRAPE", "PERSIMMON", "PUMPKIN", "GOURD", "MAIZE", "BEAN", "TOBACCO", "SWEET POTATO",
           "MUSHROOM", "BERRY", "NUT", "FLOWER", "GRASS", "VINE", "WILLOW", "THORN", "FRUIT", "CASSAVA", "PLUM",
           "STRAWBERRY", "GROUNDNUT (PEANUT)", "POTATO", "CHESTNUT"],
 "Landscape and weather": ["RIVER", "LAKE", "SWAMP", "ISLAND", "SEA", "SHORE", "SPRING (OF WATER)", "WAVE", "FOREST",
           "FIELD", "CAVE", "HILL", "STORM", "WIND", "WINTER", "SUMMER", "YEAR", "THUNDER", "LIGHTNING", "RAINBOW",
           "FOG", "ICE", "MUD", "SALT"],
 "Material culture and subsistence": ["CANOE", "BOAT", "PADDLE", "BOW", "ARROW", "SPEAR", "FISHNET", "BASKET", "POT",
           "MORTAR", "PESTLE", "HOUSE", "VILLAGE", "TOWN", "MAT", "ROPE", "BEAD", "SHELL", "AXE", "KNIFE", "CLUB",
           "BLANKET", "PIPE", "DRUM", "RATTLE", "FISHHOOK", "HOE", "SPOON", "PLATE", "CUP", "BREAD",
           "HONEY", "FAT (ORGANIC SUBSTANCE)", "FLOUR", "OIL (ORGANIC SUBSTANCE)", "BALL", "BUY", "SELL", "HUNT", "FISHING", "PLANT (SOMETHING)",
           "COOK (SOMETHING)", "GRIND", "WEAVE", "SEW", "LEATHER", "FEATHER"],
 "Social and kinship": ["MOTHER", "FATHER", "OLDER BROTHER", "YOUNGER BROTHER", "OLDER SISTER", "YOUNGER SISTER",
           "MOTHER'S BROTHER", "CHILD (DESCENDANT)", "SON", "DAUGHTER", "GRANDFATHER", "GRANDMOTHER", "HUSBAND", "WIFE",
           "CHIEF", "WAR", "ENEMY", "FRIEND", "SLAVE", "GUEST", "DANCE", "SONG", "GHOST", "MEDICINE", "WITCH",
           "CLAN", "SPIRIT", "SHAMAN (FOLK HEALER)", "SORCERER", "GRANDCHILD", "BROTHER-IN-LAW", "SISTER-IN-LAW"],
}
EURO = ["HORSE", "COW", "PIG", "CHICKEN", "GOAT", "SHEEP", "CAT", "ORANGE (FRUIT)", "PEACH", "WATERMELON", "SUGAR",
        "COFFEE", "MONEY", "IRON", "GUN", "CLOTH", "SHIRT", "HAT", "SHOE", "BOTTLE", "BOX", "KEY", "CHURCH", "PRIEST",
        "CROSS", "BOOK", "PAPER", "SOLDIER", "SHIP", "BELL"]


def main():
    cc = pd.read_csv(os.path.join(CC, "concepticon.tsv"), sep="\t")
    gl = {g.upper(): (i, g) for i, g in zip(cc.ID, cc.GLOSS)}
    wold = pd.read_csv(os.path.join(EXT, "wold", "cldf", "parameters.csv"))
    bscore = wold.dropna(subset=["Concepticon_ID"]).groupby("Concepticon_ID").Borrowed_score.mean()
    sw = pd.read_csv(os.path.join(CC, "conceptlists", "Swadesh-1952-200.tsv"), sep="\t")
    rows = []
    for r in sw.itertuples():
        rows.append(dict(list="basic", domain="Swadesh 200", gloss=r.ENGLISH, concepticon_id=r.CONCEPTICON_ID,
                         concepticon_gloss=r.CONCEPTICON_GLOSS))
    missing = []
    for dom, items in list(EXT_LIST.items()) + [("Post-contact (validation block)", EURO)]:
        for g in items:
            hit = gl.get(g.upper())
            if hit is None:
                missing.append((dom, g))
                rows.append(dict(list="extended" if dom != "Post-contact (validation block)" else "european",
                                 domain=dom, gloss=g.lower(), concepticon_id=None, concepticon_gloss=None))
            else:
                rows.append(dict(list="extended" if dom != "Post-contact (validation block)" else "european",
                                 domain=dom, gloss=g.lower(), concepticon_id=hit[0], concepticon_gloss=hit[1]))
    df = pd.DataFrame(rows)
    df["wold_borrowed_score"] = df.concepticon_id.map(lambda x: round(bscore.get(x, float("nan")), 3) if pd.notna(x) else None)
    asjp = set(pd.read_csv(os.path.join(ROOT, "cldf", "parameters.csv")).Concepticon_ID.dropna().astype(int))
    df["in_asjp100"] = df.concepticon_id.map(lambda x: pd.notna(x) and int(x) in asjp)
    df = df.drop_duplicates(subset=["list", "concepticon_id", "gloss"])
    df.to_csv(os.path.join(ROOT, "concept_lists", "concept_list_planned.csv"), index=False)
    print(df.groupby("list").size()); print("missing:", missing)
    print(df.groupby("list").wold_borrowed_score.describe())


if __name__ == "__main__":
    main()
