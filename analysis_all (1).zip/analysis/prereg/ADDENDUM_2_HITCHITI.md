# Pre-registration Addendum 2: H1 and a Georgia-era check with Hitchiti

Frozen 2026-10-10 (UTC time and hashes in `ADDENDUM_2_HASHES.txt`). Written after the main results and Addendum 1 were known, and before any similarity involving Hitchiti was computed.

## Data

- **Source.** Gatschet (1884), *A Migration Legend of the Creek Indians*, vol. 1, supplied by Dennis. The forms come from the comparative table on p. 56, the Hitchiti sketch on pp. 80 to 83, and one place-name gloss on p. 71.
- **Coverage.** 30 forms for 29 ASJP concepts (`cldf_addendum/hitchiti_forms.csv`).
- **Normalization of Gatschet's spelling.**
  - tch becomes tʃ; dsh becomes dʒ; sh becomes ʃ.
  - An apostrophe before l ('l) marks the voiceless lateral and becomes ɬ.
  - Accents, macrons and other apostrophes are dropped; y becomes j.
- **Loose mappings, flagged in the file:**
  - tree includes ahí 'wood';
  - hand is the possessed form ílbi;
  - yellow (lakni) comes from a place-name gloss.

## Disclosure

While transcribing, I saw that 3 of the 20 Mikasuki residue concepts are covered by Gatschet: who (Hitchiti nó'li), tree (ā'pi, ahí) and fire (íti). The Mikasuki forms (noɬ, ahi, iti) look cognate. Part A therefore documents an expected outcome rather than testing blind.

## Analyses (SCA, panel and seed as frozen)

- **A. H1 dating (criterion C6).**
  - For each Mikasuki residue concept that Gatschet covers, ask whether the Mikasuki form is attested in Hitchiti. Attested means SCA ≥ 0.55, or clustering with the Hitchiti form when Hitchiti is added to the frozen Stage 2 run.
  - H1 predicts that residue items are absent from Hitchiti. For the checkable subset, H1 counts as supported only if more than half of the items lack a Hitchiti cognate.
  - The other residue concepts remain unassessed.
- **B. Hitchiti residue.** These are Hitchiti items with no cognate in Choctaw, Chickasaw, Alabama, Koasati or Creek. Mikasuki, its sister, is excluded from this filter.
- **C. Georgia-era check (descriptive).** Hitchiti (row) x Timucua (column), frozen two-way design and rule set A, run twice:
  - over all shared concepts;
  - over the Hitchiti residue, if it has 5 or more concepts.

  The proposal (section 2.4) suggests a Timucua layer could predate the move south. A positive result would be treated as a lead, not a finding, since this is a post hoc addition.
- **D. Candidates.** Per-concept p-values for Hitchiti against Timucua, descriptive only.
