# Pre-registration: Workstream B pilot (Timucua contact detection)

Project: Recovering Timucua (Phaistos Labs), Dennis Crowley
Frozen: 2026-10-10 (UTC time and SHA-256 hashes in `PREREG_HASHES.txt`)
Status at freezing: Stages 1 to 3 are complete (Muskogean only). No similarity between Timucua and any other language has been computed.

## 0. Disclosure

- The raw ASJP lists for Timucua and Mikasuki were viewed while inspecting the data. No Timucua similarity score of any kind existed when this document was frozen. The precomputed similarity grid (`results/grid/`) contains no Timucua pairs; they are computed only after freezing (`05_similarity_grid.py post`).
- Choices made after viewing the Muskogean data (Creek suffix rule R4, the strict-residue cut of 0.40, the Proto-Muskogean cross-check) used Muskogean data only.
- Three rounds of validation shaped the decision rule (section 6): Spanish loans in WOLD, a placebo run with non-Timucua stand-in donors, and dry runs of the full code with Basque, Afar and Kazakh standing in for Timucua.
  - The Basque dry run passed the original rule (a)+(b)+(c). That led to the two-way design.
  - The Kazakh dry run passed a pooled version of the two-way test for H3. The cause was a stand-in donor column with unusually high variance. That led to the final row-and-column rank form of (c*).
  - Every change was made before any Timucua comparison existed.

## 1. Data

| Role | Languages | Source |
|---|---|---|
| Donor candidate | Timucua | ASJP (Granberry 1993) |
| Recipients | Mikasuki, Muscogee (Creek) | ASJP (Broadwell n.d. for Mikasuki) |
| Stage 2 family | + Choctaw, Chickasaw, Alabama, Koasati | ASJP |
| Stage 2 cross-check | Proto-Muskogean (33 concepts) | ASJP (Booker 2005) |
| Stage 3 filter | Spanish, English | ASJP |
| Calibration | Mobilian Jargon x Choctaw; Mikasuki x Creek; Koasati x Alabama; Yuchi x Creek; Natchez x Creek | ASJP (Yuchi and Natchez: 40-item lists) |
| Exploratory | Warao (Granberry's proposed relative) | ASJP |
| Control panel | 50 languages, one per family (`cldf/control_panel.csv`) | ASJP |

- Concept list: the ASJP 100-item Swadesh list. The planned 200 + 184 + 30 list (`concept_lists/concept_list_planned.csv`) cannot yet be filled from public data.
- Pinned versions: `cldf/provenance.json` (ASJP commit cf4bf0d, WOLD 1df62b9, IDS bf6c9f8, Concepticon a89063d).
- Not available: Hitchiti and Apalachee. This blocks H1 and H4.
- Normalization (logged per form in `cldf/normalization_log.csv`):
  - R1: ASJP's low vowel, written ɐ, becomes a.
  - R2: ASJP L in Muskogean becomes ɬ.
  - R3: boundary markers are dropped.
  - R4: the Creek infinitive suffix -ita is stripped (Martin 2011).

## 2. Control panel rule (applied before any Timucua comparison)

- Candidates: ASJP doculects outside the North America macroarea.
- Excluded:
  - every family proposed as a Timucua relative (Muskogean, Algic, Siouan, Cariban, Arawakan, Chibchan, Warao);
  - Indo-European;
  - pidgins and artificial languages;
  - long-extinct languages;
  - any list with fewer than 90 of the 100 concepts.
- Each remaining language gets a 5-feature phonotactic profile, z-scored: mean segments per form, share of vowel-final forms, vowel share, mean consonant-cluster length, inventory size.
- From each family, the doculect closest to Mikasuki is kept. The 50 nearest families form the panel.
- Primary control: ANGAATAHA (Angan).

## 3. Stages 2 and 3 (run before freezing; outputs frozen)

- **Stage 2.**
  - LexStat with 1,000 permutations, infomap clustering at t = 0.55, plus SCA clustering at t = 0.45.
  - An item is inherited if either method links it to another Muskogean language.
  - A concept counts as residue only if none of its forms is inherited.
  - Residue items are also checked against Booker's (2005) Proto-Muskogean forms, with removal at SCA ≥ 0.55. No items were removed.
- **Stage 3.** Residue items with SCA ≥ 0.55 to the same-concept Spanish or English form are removed.
- **Frozen residue** (`results/residue_concepts.json`):
  - Mikasuki primary (20): who, not, many, small, tree, root, flesh, egg, head, belly, breasts, know, fly, give, rain, fire, ash, burn, green, full. Of these, 15 are attested in Timucua.
  - Mikasuki strict (8): who, small, flesh, head, belly, breasts, burn, green.
  - Creek primary (32), Creek strict (16), and Creek keeping European-flagged items (35).

## 4. Similarity and statistics

- **Measures.**
  - SCA (primary): 1 minus the normalized SCA alignment distance (LingPy, global mode).
  - NED: 1 minus normalized edit distance over Dolgopolsky classes.
  - TPG: match of the first two consonant classes (Turchin et al. 2010).
- **Concept similarity:** the maximum over synonym pairs.
- **S:** the mean over focal concepts of sim(recipient_c, donor_c). Only concepts attested in both lists count.
- **Permutation null:** donor concept labels are drawn without replacement from all attested donor concepts. The focal cell uses 10,000 permutations; reference cells use 2,000. Seed 20261010.
  - p_perm = (1 + #{S_perm ≥ S_obs}) / (1 + n_perm).
  - ΔS = S_obs − E[S_perm], where E[S_perm] is exact.
  - z = ΔS / SD(S_perm).
- **Two-way control design.**
  - Grid: rows are the recipient plus the 50 panel languages; columns are the donor plus the 50 panel languages.
  - Each cell (i, j) is computed over the focal concept set, keeping only concepts both languages attest.
  - A cell needs at least 60% of the focal items.
  - An additive model z_ij = μ + r_i + c_j is fitted. The fit excludes the diagonal, the focal cell, and every cell pairing two languages from the same macroarea (possible areal contact).
  - The contact statistic is the focal cell's leave-cell-out interaction residual e.
  - e is ranked twice:
    - p_row: within its row, against the recipient paired with the 50 stand-in donors;
    - p_col: within its column, against the donor paired with the 50 stand-in recipients.
  - p_max = max(p_row, p_col). Each rank p = (1 + #{reference e ≥ e_focal}) / (1 + N_reference), with leave-cell-out reference residuals.
  - The smallest attainable p_max is about 0.02. Passing (c*) therefore requires the focal pair to rank first or second in both its row and its column.
  - A pooled rank over all reference cells (p_twoway) is also reported. It is not used for decisions, because different rows and columns have different spreads.

## 5. Decision rules

**H2 (Timucua source).** The confirmatory test is Mikasuki primary residue x Timucua, using SCA.
- Rule set A (primary):
  - (a) p_perm < 0.05;
  - (c*) p_max < 0.05.
- Rule set B (original protocol plus the panel rule):
  - (a);
  - (b) ΔS above the primary control's ΔS (control in the recipient role, same column);
  - (c) ΔS above the 95th percentile of the panel's ΔS in the same column.

Verdicts:
- **Supported:** both rule sets pass.
- **Inconclusive:** exactly one rule set passes.
- **H0 retained:** neither passes.

Creek, the strict residue, the version keeping European-flagged items, and the NED and TPG measures are secondary. They cannot rescue a failed primary test.

Robustness checks (pre-registered; reported whatever the verdict):
- **Stratified sensitivity.** The confirmatory test is rerun with permutations restricted to 5 semantic strata (action, body, thing, property, other; `cldf/concept_strata.csv`, from Concepticon fields).
- **Leave-one-concept-out.** The confirmatory verdict is recomputed with each concept dropped in turn. A positive verdict that depends on a single concept is reported as fragile.
- **Donor-panel percentile.** Timucua's rank among the 50 panel languages acting as stand-in donors for the same Mikasuki items is reported. In the placebo run, 0 to 2 of 50 stand-in donors passed rule set A on the Mikasuki and Creek rows.

**Candidate level.**
- Each residue item gets an exact p-value: its true-concept match is ranked among its matches to every other Timucua concept.
- Benjamini–Hochberg is applied within each recipient at q = 0.05.
- Expected ceiling: the smallest possible p is about 0.011 (87 Timucua concepts). With 15 tests, BH can reject only if about 5 or more items all sit at the minimum rank, so zero BH survivors is the expected outcome even with a few real loans.

**Tiers (proposal, Table 2).**
- C1: residue.
- C2: survives BH.
- C3: same concept (true by construction).
- C4: a leave-one-out bigram model over SCA classes gives the form a higher per-segment log-likelihood under Timucua than under pooled Muskogean.
- C5 and C6: flagged for expert or archival review; these data cannot assess them.
- C7: not removed in Stage 3.

Tier assignment:
- **Strong:** at least 6 criteria, including C1 and C2. This is unreachable in the pilot because C5 and C6 cannot be assessed.
- **Possible:** C1, C3, C4 and C7 are met, and the uncorrected p ≤ 0.05.
- **Rejected:** everything else.

If H2 is not supported, tiers are descriptive only.

**H3 (direction).**
- (i) Timucua (rows) x MUSK_INHERITED (columns), two-way design. MUSK_INHERITED is the pseudo-language of Muskogean cognate sets attested in at least 3 of the 6 languages.
- (ii) Count the items with uncorrected candidate p ≤ 0.05 in each direction. Test each count against a 5% chance rate (one-sided binomial).
- H3 is supported if (i) passes (a) and (c*) and the Muskogean-to-Timucua rate exceeds the Timucua-to-Muskogean rate.

**H4 and H1.** Both are blocked. The following are reported instead:
- the calibration in section 6;
- residue rates by Muskogean language.

**Exploratory.**
- Warao x Timucua, two-way design.
- Typological overlap in WALS.

## 6. Validation (completed before freezing; `validation/`)

**Known contact: Spanish loans.**
- Data: 7 WOLD languages compared with IDS Spanish, 450 concepts each.
- Aggregate p_perm = 0.0001 in all 7.
- Candidate-level BH: precision 0.92 to 1.00, recall 0.60 to 0.81; AUC 0.88 to 0.94.
- On the ASJP-100 subset: 3 of 7 languages reach p < 0.05 and there are 0 BH rejections.

**Stage 3 filter.** The 0.55 cut catches 75% of known Spanish loans and wrongly flags 3.2% of native words.

**Power with real Spanish loans planted** (residue share 21%):
- The permutation test alone has a false-positive rate of 8% to 10%.
- At 100 concepts, aggregate power is 0.50 with 2 loans, 0.77 with 3 and 0.88 with 4.
- At 350 concepts, power is 0.83 with 6 loans and 0.94 with 8.
- These are upper bounds, because Spanish loans are recent and transparent.

**Placebo** (50 panel languages as stand-in donors, Mikasuki or Creek residue concepts):

| Rule | False-positive rate |
|---|---|
| Permutation test alone | 8% to 10% across all cells; up to 12% on the Mikasuki row; 18% to 30% for full 95-concept lists |
| Original rule (a)+(b)+(c) | 2% to 4% for residue sets; 8% to 10% (up to 12%) on Muskogean rows with full lists |
| Pooled two-way rank (not used) | 4% to 5% across all cells, but 6% to 8% in some rows and columns (heteroscedastic) |
| **Final rule (a)+(c*)** | **1.5% to 2.3% across all cells; 0% to 4% on any focal row or column** |

**Calibration** (two-way, SCA):

| Pair | z | p_max | Detected? |
|---|---|---|---|
| Mobilian Jargon x Choctaw | 21.4 | 0.020 (minimum possible) | yes |
| Mikasuki x Creek | 18.6 | 0.020 | yes |
| Koasati x Alabama | 31.1 | 0.020 | yes |
| Yuchi x Creek (documented contact) | 1.1 | 0.29 | no |
| Natchez x Creek (documented contact) | 1.0 | 0.25 | no |

The design detects inheritance and pidginization. It does not detect documented historical contact in basic vocabulary at 33 to 38 concepts. A Timucua null at this scale can therefore rule out only a large layer.

**Stratified check.**
- Under the pooled two-way rank, permuting within semantic strata leaves the false-positive rate about the same: 4.3% across all cells, 2% to 6% on the focal rows.
- The calibration pattern is unchanged: Mobilian x Choctaw z = 16.8, Mikasuki x Creek z = 14.4, Koasati x Alabama z = 24.7, Yuchi x Creek z = 0.6, Natchez x Creek z = 1.3.
- The primary analysis therefore stays unstratified, as first specified; the stratified version is a sensitivity check.
