# Pre-registration Addendum 1: H4 calibration with Apalachee

Frozen 2026-10-10 (UTC time and hashes in `ADDENDUM_1_HASHES.txt`). Written after the main pilot results were known, and before any similarity between Apalachee and another language was computed.

## Why an addendum

The main pre-registration marked H4 as blocked for lack of Apalachee data. Dennis then supplied the three primary sources: Kimball (1988) "An Apalachee Vocabulary", Kimball (1987) "A Grammatical Sketch of Apalachee", and Haas (1949) "The Position of Apalachee in the Muskogean Family". The main results (H2 null for Mikasuki and Creek) were already known when this addendum was written. It is therefore a calibration check: it cannot rescue or overturn the frozen H2 verdict.

## Data

- **Source.** Kimball's (1988) phonemic retranscriptions of the 1688 Apalachee letter and the Paina document, mapped to the ASJP 100-item concepts. The wordlist is in `cldf_addendum/apalachee_forms.csv`.
- **Coverage.** The vocabulary covers 24 concepts with 27 forms.
- **Loose mappings, flagged in the file:**
  - many = finha 'much; true'
  - big = coba 'great'
  - flesh = a:nip 'body'
  - walk = aya 'to go'
  - say = innota / yalka 'to speak'
  - name = nakayo (Kimball's gloss is uncertain)
- **Segmentation.** Kimball's c = tʃ; y = j; a colon marks a long vowel. No other normalization is applied.
- **Expert cognate judgments.** These are taken from Kimball's entries. A form with listed Muskogean cognates counts as inherited. Kimball lists none for 6 forms: innota, yalka, niko 'sun', hitok 'moon', fihla 'good' and nakayo 'name'.
- **Expert statement on contact (Kimball 1988: 388).** "There is little relationship apparent between Apalachee and Timucua." Only one shared word is found: holahta, Timucua holata 'chief', judged a loan from Apalachee into Timucua. In addition, the place name Ibitachuco contains Timucua ibita 'river'.

## Analyses (all SCA, panel and seed as frozen)

- **A. Stage 2 check.**
  - Run the frozen automated cognate detection (LexStat at t = 0.55 or SCA at t = 0.45, any Muskogean partner) on the six Muskogean lists plus Apalachee.
  - Score the result against Kimball's judgments. Report agreement and the recall of Kimball's cognates.
- **B. H4 test.**
  - Apalachee (row) x Timucua (column) over every Apalachee concept Timucua attests, using the frozen two-way design. Rule set A: p_perm < 0.05 and p_max < 0.05.
  - The full concept set is used, not a residue: the expert residue is only 5 to 6 items, too few to test.
- **C. H4 comparison.** Mikasuki x Timucua over the same concept set.
  - **H4 supported** if Apalachee x Timucua passes rule set A and its ΔS exceeds the Mikasuki ΔS on the same concepts.
  - Otherwise H4 is not supported.
- **D. Candidates (descriptive).** Each Apalachee form gets a candidate p-value against Timucua, computed as in the main analysis.

## Prediction stated in advance

Kimball found only one shared word in the whole surviving lexicon, and it is not on the 100-item list. The Yuchi and Natchez calibrations also showed that documented contact is invisible at 30 to 40 concepts. The expected outcome is therefore a null. A null here says the pipeline cannot see contact even with Timucua's closest Muskogean neighbor at this list size. It does not say there was no contact.
