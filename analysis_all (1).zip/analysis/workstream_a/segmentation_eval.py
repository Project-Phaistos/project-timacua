"""Workstream A, ready for the corpus: unsupervised segmentation scored against gold boundaries.

Usage (once Broadwell's corpus and a gold segmentation are available):
  python3 segmentation_eval.py --words corpus_words.txt --gold gold_segmentations.tsv [--out results_dir]
    corpus_words.txt         one normalized Timucua word token per line (frequency matters: keep repeats)
    gold_segmentations.tsv   word<TAB>morph1 morph2 ... (boundaries from Broadwell 2024's affix inventory)
Outputs: boundary precision / recall / F1 (micro over gold types), the model's segmentations, and
recurrent segments the model posits that are absent from the gold inventory (candidates for
expert review, NOT findings, per proposal section 6.1).

  python3 segmentation_eval.py --selftest   runs on a synthetic agglutinative toy language.
"""
import argparse
import collections
import os
import random

import morfessor


def boundaries(morphs):
    out, pos = set(), 0
    for m in morphs[:-1]:
        pos += len(m)
        out.add(pos)
    return out


def train(tokens, seed=1):
    random.seed(seed)
    io = morfessor.MorfessorIO()
    model = morfessor.BaselineModel()
    counts = collections.Counter(tokens)
    model.load_data([(c, w) for w, c in counts.items()], count_modifier=lambda x: 1 + int(x ** 0.5))
    model.train_batch()
    return model


def evaluate(model, gold):
    tp = fp = fn = 0
    seg = {}
    for w, g in gold.items():
        pred = model.viterbi_segment(w)[0]
        seg[w] = pred
        pb, gb = boundaries(pred), boundaries(g)
        tp += len(pb & gb); fp += len(pb - gb); fn += len(gb - pb)
    p = tp / max(1, tp + fp); r = tp / max(1, tp + fn)
    return dict(precision=p, recall=r, f1=2 * p * r / max(1e-9, p + r), types=len(gold)), seg


def novel_segments(seg, gold, min_count=5):
    gold_morphs = collections.Counter(m for g in gold.values() for m in g)
    model_morphs = collections.Counter(m for s in seg.values() for m in s)
    return [(m, c) for m, c in model_morphs.most_common() if c >= min_count and m not in gold_morphs]


def selftest():
    rng = random.Random(7)
    stems = ["".join(rng.choice("ptkmnslh") + rng.choice("aeiou") for _ in range(rng.randint(1, 3))) for _ in range(300)]
    prefixes, suffixes = ["ni", "chi", "", ""], ["ta", "ma", "le", "bo", "", "", ""]
    gold, tokens = {}, []
    for _ in range(20000):
        st, pr, su = rng.choice(stems), rng.choice(prefixes), rng.choice(suffixes)
        morphs = [m for m in (pr, st, su) if m]
        w = "".join(morphs)
        gold.setdefault(w, morphs)
        tokens.append(w)
    model = train(tokens)
    scores, seg = evaluate(model, gold)
    print("self-test (toy language):", {k: round(v, 3) if isinstance(v, float) else v for k, v in scores.items()})
    assert scores["f1"] > 0.5, "segmentation pipeline failed the self-test"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--words"); ap.add_argument("--gold"); ap.add_argument("--out", default="workstream_a_results")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    tokens = [l.strip() for l in open(a.words, encoding="utf8") if l.strip()]
    gold = {}
    for line in open(a.gold, encoding="utf8"):
        if "\t" in line:
            w, ms = line.rstrip("\n").split("\t", 1)
            gold[w] = ms.split()
    model = train(tokens)
    scores, seg = evaluate(model, gold)
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "scores.txt"), "w") as f:
        f.write(str(scores) + "\n")
    with open(os.path.join(a.out, "segmentations.tsv"), "w") as f:
        for w, s in sorted(seg.items()):
            f.write(f"{w}\t{' '.join(s)}\t{' '.join(gold[w])}\n")
    with open(os.path.join(a.out, "novel_segments_for_review.tsv"), "w") as f:
        for m, c in novel_segments(seg, gold):
            f.write(f"{m}\t{c}\n")
    print(scores)


if __name__ == "__main__":
    main()
