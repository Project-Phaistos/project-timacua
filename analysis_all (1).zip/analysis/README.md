# Recovering Timucua: pilot package

Code, data and results for the pilot run of the proposal "Recovering Timucua: A Computer-Assisted Framework for Text Analysis and Contact Detection in Mikasuki and Muscogee" (Crowley, Phaistos Labs, Sept. 2026).

## Headline

**Pre-registered confirmatory test (Mikasuki residue x Timucua, SCA): H0 retained.**
- 15 concepts, ΔS = +0.024, z = 0.64, p_perm = 0.26.
- Timucua ranks 29th of 51 candidate donors for Mikasuki; Mikasuki ranks 28th of 51 candidate recipients for Timucua.
- All 17 secondary tests, the stratified check and all 15 leave-one-out runs also retain H0.
- No candidate loan reaches even uncorrected p ≤ 0.05.

**H4 (Addendum 1, frozen before the run).** Apalachee x Timucua over 24 concepts from Kimball (1988) is null too: z = −0.70, p = 0.74, 48th of 51. Automated Stage 2 recovers 19 of Kimball's 21 cognates.

**H1 (Addendum 2, frozen before the run).** Gatschet's (1884) Hitchiti covers 3 of the 20 Mikasuki residue words (who, tree, fire), and all 3 are attested there, so H1 is not supported for the checkable subset. Hitchiti x Timucua over 28 concepts is null (z = −0.27, p = 0.60, p_max = 0.75).

**Source checks (descriptive, no Timucua comparison).**
- Haas's 1937 Hitchiti notebook (APS box 19) agrees with Gatschet on all 17 shared concepts but covers none of the other 17 residue words.
- Boynton (1982) attests 5 of the 8 strict Mikasuki residue forms (one only partly), so the residue is not an ASJP transcription error.
- Correction: `results/h1_hitchiti/h1_summary.json` reports `absent_from_hitchiti: -6`. That is a bug in the frozen script (`~` on an object column); the right count is 0, and the verdict is unchanged. See `haas1937_boynton_summary.json`.

**Power caveat.** The same design does not detect documented Yuchi–Creek or Natchez–Creek contact at this list size. The null rules out only a large Timucua layer in basic vocabulary.

**Lead for H3 (post hoc, descriptive only).**
- 7 of 63 Timucua items match widespread Muskogean forms at p ≤ 0.05. Only 1 of 50 placebo languages does as well.
- The strongest are *efa* 'dog' (Muskogean *ifa*), *neha* 'grease' (*niha*) and *ilake* 'night' (*nilaki*).
- The pre-registered H3 test was null.

## Layout

| Folder | Contents |
|---|---|
| `cldf/` | CLDF Wordlist (64 languages, 6,716 forms), normalization log, control panel, concept strata, provenance (pinned commits) |
| `concept_lists/` | Planned 200 basic + 184 extended + 30 post-contact concepts, with Concepticon IDs and WOLD borrowability |
| `prereg/` | `PREREGISTRATION.md` and `PREREG_HASHES.txt`. Frozen 2026-10-10T15:01:36Z; fingerprint `5ee3bff3…0c256308`. Addendum 1 (Apalachee, H4): frozen 15:32:59Z, fingerprint `8f96f5be…ba2b3bb47`. Addendum 2 (Hitchiti, H1): frozen 15:42:23Z, fingerprint `d412d822…1933093dce` |
| `cldf_addendum/` | Apalachee wordlist from Kimball (1988), with expert cognate flags; Hitchiti from Gatschet (1884) and Haas's 1937 notebook; Boynton (1982) check of the Mikasuki residue forms |
| `validation/` | WOLD Spanish-loan validation, Stage 3 filter evaluation, power grid, placebo and calibration runs, dry runs |
| `results/` | Stage 2 and 3 outputs, all tests (`all_tests.csv`), candidate tables, H3, leave-one-out, WALS |
| `gazetteer/` | Timucua-period place names and their fates, with sources |
| `workstream_a/` | Segmentation scorer, ready for Broadwell's corpus (`--selftest` runs on a toy language) |
| `docs/` | Bibliography, data access plan, outreach drafts |
| `src/` | Pipeline scripts, in run order |

## Reproduce

```
pip install lingpy lingrex pycldf morfessor python-igraph rapidfuzz scipy pandas
git clone --depth 1 https://github.com/lexibank/asjp  (and lexibank/wold, lexibank/ids, cldf-datasets/wals, concepticon/concepticon-data)
export TIMUCUA_EXT=/path/to/those/clones
cd src
python3 01_build_dataset.py              # Stage 1: CLDF + control panel
python3 00_concept_lists.py; python3 00b_concept_strata.py
python3 02_stage2_3_residue.py           # Stages 2-3
python3 03_validation.py                 # WOLD validation + power (about 20 min)
python3 05_similarity_grid.py pre        # similarity grid without Timucua (about 20 min)
python3 06_placebo_and_calibration.py; python3 06b_stratified_check.py
python3 08_freeze_prereg.py              # refuses to run if Timucua similarities exist
python3 05_similarity_grid.py post       # Timucua pairs
python3 07_run_workstream_b.py           # Stages 4-8 (about 40 min)
python3 09_wals_typology.py
python3 10_apalachee_h4.py               # Addendum 1 (H4)
python3 11_hitchiti_h1.py                # Addendum 2 (H1)
python3 12_haas1937_boynton_checks.py    # descriptive source checks
```

`results/grid/` (61 MB) is not included in the package; `05_similarity_grid.py` regenerates it. `04_dryrun_original_rule.py` is the superseded first version, kept because the pre-registration cites its dry run.

## Data licences

- ASJP, WOLD, IDS, WALS and Concepticon are CC-BY. Cite them as listed in `docs/bibliography_and_outreach.md`.
- No contemporary community data were used.
